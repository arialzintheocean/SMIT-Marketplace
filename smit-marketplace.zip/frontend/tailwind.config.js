/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        brand: { 50: '#eef3ff', 100: '#dce7ff', 200: '#b9ceff', 500: '#2f4fb8', 600: '#1f3a96', 700: '#162d78', 800: '#0f2160', 900: '#0a1744' },
        mint: { 50: '#ecfdf6', 100: '#d1fae8', 200: '#a7f3d3', 400: '#34d399', 500: '#10b981', 600: '#059669', 700: '#047857' },
      },
      fontFamily: { sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'] },
      boxShadow: { card: '0 1px 2px rgba(15,33,96,.06), 0 4px 16px rgba(15,33,96,.06)', lift: '0 8px 30px rgba(15,33,96,.14)' },
    },
  },
  plugins: [],
}
