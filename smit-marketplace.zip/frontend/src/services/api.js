import axios from 'axios'

const api = axios.create({ baseURL: '/api' })

api.interceptors.request.use((cfg) => {
  const t = localStorage.getItem('smit_token')
  if (t) cfg.headers.Authorization = `Bearer ${t}`
  return cfg
})

api.interceptors.response.use(
  (r) => r,
  (err) => {
    const status = err.response?.status
    const url = err.config?.url || ''
    if (status === 401 && !url.includes('/auth/login')) {
      localStorage.removeItem('smit_token')
      if (!location.pathname.startsWith('/login')) location.href = '/login'
    }
    return Promise.reject(err)
  }
)

export const errMsg = (e, fallback = 'Something went wrong') =>
  e?.response?.data?.error || (e?.code === 'ERR_NETWORK' ? 'Cannot reach the server. Is the backend running?' : fallback)

export default api
