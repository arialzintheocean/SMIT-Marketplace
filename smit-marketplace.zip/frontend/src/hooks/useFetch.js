import { useCallback, useEffect, useRef, useState } from 'react'
import api, { errMsg } from '../services/api'

// Fetches a URL; optional `interval` (ms) enables periodic refresh (used for messaging/notifications).
export default function useFetch(url, { params, interval, enabled = true } = {}) {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(enabled)
  const [error, setError] = useState('')
  const key = JSON.stringify([url, params])
  const first = useRef(true)

  const load = useCallback(async (silent = false) => {
    if (!enabled || !url) return
    if (!silent) setLoading(true)
    try {
      const { data } = await api.get(url, { params })
      setData(data)
      setError('')
    } catch (e) {
      setError(errMsg(e))
    } finally {
      setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, enabled])

  useEffect(() => { first.current = true; load() }, [load])
  useEffect(() => {
    if (!interval || !enabled) return
    const t = setInterval(() => load(true), interval)
    return () => clearInterval(t)
  }, [interval, load, enabled])

  return { data, loading, error, reload: () => load(true), setData }
}
