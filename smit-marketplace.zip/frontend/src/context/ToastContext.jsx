import { createContext, useCallback, useContext, useState } from 'react'
import { CheckCircle2, XCircle } from 'lucide-react'

const ToastCtx = createContext(null)
export const useToast = () => useContext(ToastCtx)

export function ToastProvider({ children }) {
  const [items, setItems] = useState([])
  const push = useCallback((message, type = 'success') => {
    const id = Math.random()
    setItems((s) => [...s, { id, message, type }])
    setTimeout(() => setItems((s) => s.filter((x) => x.id !== id)), 3800)
  }, [])
  const toast = { success: (m) => push(m, 'success'), error: (m) => push(m, 'error') }
  return (
    <ToastCtx.Provider value={toast}>
      {children}
      <div className="fixed bottom-5 right-5 z-[100] flex flex-col gap-2">
        {items.map((t) => (
          <div key={t.id} className="flex max-w-sm items-start gap-2 rounded-xl bg-white px-4 py-3 text-sm shadow-lift ring-1 ring-slate-100 animate-[fadeIn_.2s_ease]">
            {t.type === 'success' ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-mint-500" /> : <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-500" />}
            <span>{t.message}</span>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  )
}
