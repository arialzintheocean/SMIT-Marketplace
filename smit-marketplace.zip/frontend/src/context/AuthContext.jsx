import { createContext, useCallback, useContext, useEffect, useState } from 'react'
import api from '../services/api'

const AuthCtx = createContext(null)
export const useAuth = () => useContext(AuthCtx)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(!!localStorage.getItem('smit_token'))

  const refresh = useCallback(async () => {
    if (!localStorage.getItem('smit_token')) { setUser(null); setLoading(false); return }
    try {
      const { data } = await api.get('/auth/me')
      setUser(data)
    } catch {
      localStorage.removeItem('smit_token')
      setUser(null)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { refresh() }, [refresh])

  const login = async (email, password) => {
    const { data } = await api.post('/auth/login', { email, password })
    localStorage.setItem('smit_token', data.token)
    setUser(data.user)
    return data.user
  }
  const logout = () => { localStorage.removeItem('smit_token'); setUser(null) }

  return <AuthCtx.Provider value={{ user, setUser, loading, login, logout, refresh }}>{children}</AuthCtx.Provider>
}
