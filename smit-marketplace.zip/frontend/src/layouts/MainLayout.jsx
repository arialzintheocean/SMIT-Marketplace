import { Outlet, Link } from 'react-router-dom'
import { Store } from 'lucide-react'
import Navbar from '../components/Navbar'

export default function MainLayout() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-8"><Outlet /></main>
      <footer className="border-t border-slate-100 bg-white py-6">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-2 px-4 text-sm text-slate-500">
          <span className="flex items-center gap-2 font-semibold text-brand-800"><Store className="h-4 w-4" />Smit MarketPlace</span>
          <span>Buy, sell and exchange within your campus community.</span>
          <Link to="/marketplace" className="font-medium text-brand-600 hover:underline">Browse listings</Link>
        </div>
      </footer>
    </div>
  )
}
