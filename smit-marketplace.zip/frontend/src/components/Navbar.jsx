import { useState } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { Bell, Heart, LayoutDashboard, LogOut, Menu, MessageSquare, PlusCircle, Store, X, Shield, Check } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import useFetch from '../hooks/useFetch'
import api from '../services/api'
import { timeAgo } from '../utils/format'
import { Avatar } from './ui'

function NotificationBell() {
  const [open, setOpen] = useState(false)
  const nav = useNavigate()
  const { data, reload } = useFetch('/notifications', { interval: 15000 })
  const unread = data?.unread || 0

  const click = async (n) => {
    if (!n.isRead) { await api.patch(`/notifications/${n.id}/read`).catch(() => {}); reload() }
    setOpen(false)
    if (n.link) nav(n.link)
  }
  const readAll = async () => { await api.patch('/notifications/read-all'); reload() }

  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} className="relative rounded-xl p-2 text-slate-600 hover:bg-slate-100" aria-label="Notifications">
        <Bell className="h-5 w-5" />
        {unread > 0 && <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 text-[10px] font-bold text-white">{unread}</span>}
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
          <div className="card absolute right-0 z-40 mt-2 w-80 overflow-hidden shadow-lift">
            <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
              <span className="font-bold text-brand-900">Notifications</span>
              {unread > 0 && <button onClick={readAll} className="flex items-center gap-1 text-xs font-semibold text-brand-600"><Check className="h-3 w-3" />Mark all read</button>}
            </div>
            <div className="max-h-96 overflow-y-auto">
              {!data?.items?.length && <p className="px-4 py-8 text-center text-sm text-slate-400">You're all caught up</p>}
              {data?.items?.map((n) => (
                <button key={n.id} onClick={() => click(n)} className={`block w-full border-b border-slate-50 px-4 py-3 text-left transition hover:bg-slate-50 ${n.isRead ? '' : 'bg-brand-50/60'}`}>
                  <div className="flex items-start gap-2">
                    {!n.isRead && <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-mint-500" />}
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-slate-800">{n.title}</p>
                      <p className="text-xs text-slate-500">{n.message}</p>
                      <p className="mt-0.5 text-[11px] text-slate-400">{timeAgo(n.createdAt)}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  )
}

export default function Navbar() {
  const { user, logout } = useAuth()
  const nav = useNavigate()
  const [open, setOpen] = useState(false)
  const link = ({ isActive }) => `rounded-lg px-3 py-2 text-sm font-medium transition ${isActive ? 'bg-brand-50 text-brand-700' : 'text-slate-600 hover:text-brand-700'}`

  return (
    <header className="sticky top-0 z-40 border-b border-slate-100 bg-white/85 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4">
        <Link to="/" className="flex items-center gap-2 font-extrabold text-brand-800">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-700 text-white"><Store className="h-5 w-5" /></span>
          <span className="hidden sm:block">Smit <span className="text-mint-600">MarketPlace</span></span>
        </Link>
        <nav className="ml-4 hidden items-center gap-1 md:flex">
          <NavLink to="/marketplace" className={link}>Marketplace</NavLink>
          {user && <NavLink to="/dashboard" className={link}>Dashboard</NavLink>}
          {user && <NavLink to="/my-listings" className={link}>My Listings</NavLink>}
          {user && <NavLink to="/offers" className={link}>Offers</NavLink>}
          {user && <NavLink to="/transactions" className={link}>Exchanges</NavLink>}
          {user?.role === 'admin' && <NavLink to="/admin" className={link}>Admin</NavLink>}
        </nav>
        <div className="ml-auto flex items-center gap-1.5">
          {user ? (
            <>
              <Link to="/create" className="btn-mint hidden sm:inline-flex"><PlusCircle className="h-4 w-4" />Sell</Link>
              <Link to="/wishlist" className="rounded-xl p-2 text-slate-600 hover:bg-slate-100" aria-label="Wishlist"><Heart className="h-5 w-5" /></Link>
              <Link to="/messages" className="rounded-xl p-2 text-slate-600 hover:bg-slate-100" aria-label="Messages"><MessageSquare className="h-5 w-5" /></Link>
              <NotificationBell />
              <Link to={`/profile/${user.id}`} className="ml-1"><Avatar user={user} /></Link>
              <button onClick={() => { logout(); nav('/') }} className="rounded-xl p-2 text-slate-500 hover:bg-slate-100" aria-label="Log out"><LogOut className="h-5 w-5" /></button>
            </>
          ) : (
            <>
              <Link to="/login" className="btn-ghost">Log in</Link>
              <Link to="/register" className="btn-primary hidden sm:inline-flex">Join campus</Link>
            </>
          )}
          <button className="rounded-xl p-2 md:hidden" onClick={() => setOpen(!open)}>{open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}</button>
        </div>
      </div>
      {open && (
        <div className="flex flex-col gap-1 border-t border-slate-100 bg-white p-3 md:hidden" onClick={() => setOpen(false)}>
          <NavLink to="/marketplace" className={link}>Marketplace</NavLink>
          {user && <>
            <NavLink to="/create" className={link}>Sell an item</NavLink>
            <NavLink to="/dashboard" className={link}><LayoutDashboard className="mr-1 inline h-4 w-4" />Dashboard</NavLink>
            <NavLink to="/my-listings" className={link}>My Listings</NavLink>
            <NavLink to="/offers" className={link}>Offers</NavLink>
            <NavLink to="/transactions" className={link}>Exchanges</NavLink>
          </>}
          {user?.role === 'admin' && <NavLink to="/admin" className={link}><Shield className="mr-1 inline h-4 w-4" />Admin</NavLink>}
        </div>
      )}
    </header>
  )
}
