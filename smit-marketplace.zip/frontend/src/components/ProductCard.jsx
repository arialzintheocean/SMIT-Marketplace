import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Heart, ImageOff, MapPin } from 'lucide-react'
import api, { errMsg } from '../services/api'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { inr } from '../utils/format'
import { StatusBadge } from './ui'

export function ProductImage({ product, className = '' }) {
  const src = product.images?.[0]?.imagePath
  return src ? (
    <img src={src} alt={product.title} loading="lazy" className={`object-cover ${className}`} />
  ) : (
    <div className={`flex items-center justify-center bg-slate-100 text-slate-300 ${className}`}><ImageOff className="h-8 w-8" /></div>
  )
}

export default function ProductCard({ product, wishlisted = false, onWishlistChange }) {
  const { user } = useAuth()
  const toast = useToast()
  const [saved, setSaved] = useState(wishlisted)
  const [busy, setBusy] = useState(false)
  const own = user && user.id === product.sellerId

  const toggle = async (e) => {
    e.preventDefault()
    if (!user) return toast.error('Log in to save items')
    setBusy(true)
    try {
      if (saved) await api.delete(`/wishlist/${product.id}`)
      else await api.post(`/wishlist/${product.id}`)
      setSaved(!saved)
      onWishlistChange?.(product.id, !saved)
    } catch (err) { toast.error(errMsg(err)) } finally { setBusy(false) }
  }

  return (
    <Link to={`/product/${product.id}`} className="card group overflow-hidden transition duration-300 hover:-translate-y-1 hover:shadow-lift">
      <div className="relative aspect-[4/3] overflow-hidden bg-slate-100">
        <ProductImage product={product} className="h-full w-full transition duration-500 group-hover:scale-105" />
        {product.status !== 'active' && <div className="absolute left-3 top-3"><StatusBadge status={product.status} /></div>}
        {!own && (
          <button onClick={toggle} disabled={busy} aria-label="Save to wishlist"
            className="absolute right-3 top-3 rounded-full bg-white/90 p-2 shadow transition hover:scale-110">
            <Heart className={`h-4 w-4 ${saved ? 'fill-red-500 text-red-500' : 'text-slate-500'}`} />
          </button>
        )}
      </div>
      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <h3 className="line-clamp-1 font-semibold text-slate-800">{product.title}</h3>
        </div>
        <div className="mt-1 flex items-center gap-2">
          <span className="text-lg font-extrabold text-brand-700">{inr(product.pricePaise)}</span>
          {product.negotiable && <span className="badge bg-mint-100 text-mint-700">Negotiable</span>}
        </div>
        <div className="mt-2 flex items-center justify-between text-xs text-slate-500">
          <span className="badge bg-brand-50 text-brand-700">{product.condition}</span>
          <span className="flex items-center gap-1 truncate"><MapPin className="h-3 w-3" />{product.pickupLocation}</span>
        </div>
      </div>
    </Link>
  )
}
