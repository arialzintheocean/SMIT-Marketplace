import { Loader2, AlertCircle, Inbox, Star, X } from 'lucide-react'
import { statusStyle } from '../utils/format'

export const Spinner = ({ label = 'Loading…' }) => (
  <div className="flex items-center justify-center gap-2 py-16 text-slate-500">
    <Loader2 className="h-5 w-5 animate-spin" /> <span className="text-sm">{label}</span>
  </div>
)

export const ErrorBox = ({ message, onRetry }) => (
  <div className="flex items-center gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
    <AlertCircle className="h-4 w-4 shrink-0" />
    <span className="flex-1">{message}</span>
    {onRetry && <button onClick={onRetry} className="font-semibold underline">Retry</button>}
  </div>
)

export const Empty = ({ title, hint, children }) => (
  <div className="flex flex-col items-center rounded-2xl border border-dashed border-slate-200 bg-white px-6 py-14 text-center">
    <div className="mb-3 rounded-full bg-brand-50 p-3 text-brand-600"><Inbox className="h-6 w-6" /></div>
    <p className="font-semibold text-slate-700">{title}</p>
    {hint && <p className="mt-1 max-w-sm text-sm text-slate-500">{hint}</p>}
    {children && <div className="mt-4">{children}</div>}
  </div>
)

export const StatusBadge = ({ status }) => (
  <span className={`badge capitalize ${statusStyle[status] || 'bg-slate-100 text-slate-600'}`}>{status}</span>
)

export const Stars = ({ value = 0, size = 'h-4 w-4', onChange }) => (
  <span className="inline-flex items-center gap-0.5">
    {[1, 2, 3, 4, 5].map((n) => (
      <Star
        key={n}
        onClick={onChange ? () => onChange(n) : undefined}
        className={`${size} ${n <= Math.round(value) ? 'fill-amber-400 text-amber-400' : 'text-slate-300'} ${onChange ? 'cursor-pointer hover:scale-110 transition' : ''}`}
      />
    ))}
  </span>
)

export function Modal({ open, onClose, title, children }) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-brand-900/40 p-4 backdrop-blur-sm" onClick={onClose}>
      <div className="card w-full max-w-md p-6" onClick={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-bold text-brand-900">{title}</h3>
          <button onClick={onClose} className="rounded-lg p-1 text-slate-400 hover:bg-slate-100"><X className="h-5 w-5" /></button>
        </div>
        {children}
      </div>
    </div>
  )
}

export const Avatar = ({ user, size = 'h-9 w-9' }) =>
  user?.profileImage ? (
    <img src={user.profileImage} alt="" className={`${size} rounded-full object-cover`} />
  ) : (
    <div className={`${size} flex shrink-0 items-center justify-center rounded-full bg-brand-100 text-sm font-bold text-brand-700`}>
      {(user?.name || '?').charAt(0).toUpperCase()}
    </div>
  )

export const PageHeader = ({ title, subtitle, action }) => (
  <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
    <div>
      <h1 className="text-2xl font-extrabold text-brand-900">{title}</h1>
      {subtitle && <p className="mt-1 text-sm text-slate-500">{subtitle}</p>}
    </div>
    {action}
  </div>
)
