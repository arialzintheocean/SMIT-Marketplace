export const inr = (paise) =>
  '₹' + (Number(paise || 0) / 100).toLocaleString('en-IN', { maximumFractionDigits: 2 })

export const imgUrl = (p) => p || null

export const timeAgo = (d) => {
  const s = Math.floor((Date.now() - new Date(d).getTime()) / 1000)
  if (s < 60) return 'just now'
  if (s < 3600) return `${Math.floor(s / 60)}m ago`
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`
  if (s < 604800) return `${Math.floor(s / 86400)}d ago`
  return new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
}

export const fmtTime = (d) =>
  new Date(d).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })

export const statusStyle = {
  active: 'bg-mint-100 text-mint-700',
  reserved: 'bg-amber-100 text-amber-700',
  sold: 'bg-slate-200 text-slate-600',
  removed: 'bg-red-100 text-red-600',
  pending: 'bg-amber-100 text-amber-700',
  accepted: 'bg-mint-100 text-mint-700',
  rejected: 'bg-red-100 text-red-600',
  countered: 'bg-brand-100 text-brand-700',
  withdrawn: 'bg-slate-200 text-slate-600',
  requested: 'bg-amber-100 text-amber-700',
  completed: 'bg-mint-100 text-mint-700',
  cancelled: 'bg-slate-200 text-slate-600',
  resolved: 'bg-mint-100 text-mint-700',
  dismissed: 'bg-slate-200 text-slate-600',
  suspended: 'bg-red-100 text-red-600',
}

export const RECENT_KEY = 'smit_recent'
export const pushRecent = (id) => {
  try {
    const cur = JSON.parse(localStorage.getItem(RECENT_KEY) || '[]').filter((x) => x !== id)
    localStorage.setItem(RECENT_KEY, JSON.stringify([id, ...cur].slice(0, 8)))
  } catch {}
}
export const getRecent = () => {
  try { return JSON.parse(localStorage.getItem(RECENT_KEY) || '[]') } catch { return [] }
}
