import { Link } from 'react-router-dom'
import { Trash2 } from 'lucide-react'
import api, { errMsg } from '../services/api'
import useFetch from '../hooks/useFetch'
import { useToast } from '../context/ToastContext'
import { Empty, ErrorBox, PageHeader, Spinner, StatusBadge } from '../components/ui'
import { ProductImage } from '../components/ProductCard'
import { inr } from '../utils/format'

export default function Wishlist() {
  const { data, loading, error, reload } = useFetch('/wishlist')
  const toast = useToast()
  const remove = async (pid) => {
    try { await api.delete(`/wishlist/${pid}`); toast.success('Removed from wishlist'); reload() } catch (e) { toast.error(errMsg(e)) }
  }
  if (loading) return <Spinner />
  return (
    <div>
      <PageHeader title="Your wishlist" subtitle="Items you've saved for later." />
      {error && <ErrorBox message={error} onRetry={reload} />}
      {!data?.items?.length ? <Empty title="Nothing saved yet" hint="Tap the heart on any listing to save it here."><Link to="/marketplace" className="btn-primary">Browse marketplace</Link></Empty> : (
        <div className="grid gap-4 md:grid-cols-2">
          {data.items.map((w) => (
            <div key={w.id} className="card flex gap-4 p-3">
              <Link to={`/product/${w.productId}`} className="h-28 w-32 shrink-0 overflow-hidden rounded-xl"><ProductImage product={w.product} className="h-full w-full" /></Link>
              <div className="flex min-w-0 flex-1 flex-col justify-between">
                <div>
                  <Link to={`/product/${w.productId}`} className="line-clamp-1 font-semibold hover:text-brand-700">{w.product.title}</Link>
                  <p className="font-extrabold text-brand-700">{inr(w.product.pricePaise)}</p>
                  <div className="mt-1 flex items-center gap-2">
                    <StatusBadge status={w.available ? 'active' : w.product.status} />
                    {!w.available && <span className="text-xs text-slate-400">No longer available</span>}
                  </div>
                </div>
                <button onClick={() => remove(w.productId)} className="flex items-center gap-1 self-end text-xs font-medium text-slate-400 hover:text-red-500"><Trash2 className="h-3.5 w-3.5" />Remove</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
