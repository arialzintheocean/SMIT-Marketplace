import { Link } from 'react-router-dom'
import { Eye, Handshake, Heart, Inbox, Package, PackageCheck, ShoppingBag, TrendingUp } from 'lucide-react'
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import useFetch from '../hooks/useFetch'
import { useAuth } from '../context/AuthContext'
import { ErrorBox, PageHeader, Spinner, StatusBadge } from '../components/ui'
import { inr, timeAgo } from '../utils/format'

const Stat = ({ icon: Icon, label, value, to, tone = 'brand' }) => (
  <Link to={to} className="card group p-5 transition hover:-translate-y-1 hover:shadow-lift">
    <span className={`mb-3 inline-flex rounded-xl p-2.5 ${tone === 'mint' ? 'bg-mint-50 text-mint-600' : 'bg-brand-50 text-brand-700'}`}><Icon className="h-5 w-5" /></span>
    <p className="text-2xl font-extrabold text-brand-900">{value}</p>
    <p className="text-sm text-slate-500">{label}</p>
  </Link>
)

export default function Dashboard() {
  const { user } = useAuth()
  const { data, loading, error, reload } = useFetch('/dashboard', { interval: 30000 })
  if (loading) return <Spinner />
  if (error) return <ErrorBox message={error} onRetry={reload} />
  const a = data.analytics

  return (
    <div>
      <PageHeader title={`Hi, ${user.name.split(' ')[0]} 👋`} subtitle="Here's what's happening with your campus trading."
        action={<Link to="/create" className="btn-mint">Sell an item</Link>} />
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Stat icon={Package} label="Active listings" value={data.activeListings} to="/my-listings" />
        <Stat icon={PackageCheck} label="Sold products" value={data.soldProducts} to="/my-listings" tone="mint" />
        <Stat icon={Handshake} label="Pending offers received" value={data.pendingOffers} to="/offers" />
        <Stat icon={ShoppingBag} label="Purchase requests received" value={data.receivedRequests} to="/transactions" tone="mint" />
        <Stat icon={Heart} label="Saved products" value={data.savedProducts} to="/wishlist" />
        <Stat icon={Inbox} label="Unread messages" value={data.unreadMessages} to="/messages" tone="mint" />
        <Stat icon={Handshake} label="My open offers" value={data.myPendingOffers} to="/offers" />
        <Stat icon={ShoppingBag} label="My open requests" value={data.sentRequests} to="/transactions" tone="mint" />
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-3">
        <div className="card p-6 lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="flex items-center gap-2 font-bold text-brand-900"><TrendingUp className="h-4 w-4 text-mint-600" />Listing performance</h2>
            <span className="text-xs text-slate-500">{a.totalViews} total views</span>
          </div>
          {a.listings.length ? (
            <div className="h-64">
              <ResponsiveContainer>
                <BarChart data={a.listings.slice(0, 8).map((l) => ({ name: l.title.length > 14 ? l.title.slice(0, 14) + '…' : l.title, Views: l.views, Interested: l.interested }))}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} /><YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                  <Tooltip /><Bar dataKey="Views" fill="#1f3a96" radius={[6, 6, 0, 0]} /><Bar dataKey="Interested" fill="#10b981" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : <p className="py-10 text-center text-sm text-slate-400">Post a listing to see analytics.</p>}
          <div className="mt-4 grid gap-3 border-t border-slate-100 pt-4 sm:grid-cols-3">
            <div><p className="label">Completed sales</p><p className="text-lg font-bold">{a.completedSales}</p></div>
            <div><p className="label">Total earned</p><p className="text-lg font-bold">{inr(a.totalEarnedPaise)}</p></div>
            <div><p className="label">Most viewed</p>
              {a.mostViewed ? <Link to={`/product/${a.mostViewed.id}`} className="flex items-center gap-1 text-sm font-semibold text-brand-700 hover:underline"><Eye className="h-3.5 w-3.5" />{a.mostViewed.title.slice(0, 22)} ({a.mostViewed.views})</Link> : <p className="text-sm text-slate-400">—</p>}</div>
          </div>
        </div>

        <div className="card p-6">
          <h2 className="mb-4 font-bold text-brand-900">Recent activity</h2>
          {!data.recentActivity.length ? <p className="text-sm text-slate-400">Nothing yet.</p> : (
            <ul className="space-y-3">{data.recentActivity.map((n) => (
              <li key={n.id}><Link to={n.link || '/dashboard'} className="block rounded-lg p-1 hover:bg-slate-50">
                <p className="text-sm font-semibold">{n.title}</p><p className="text-xs text-slate-500">{n.message}</p><p className="text-[11px] text-slate-400">{timeAgo(n.createdAt)}</p>
              </Link></li>
            ))}</ul>
          )}
        </div>
      </div>

      {a.listings.length > 0 && (
        <div className="card mt-6 p-6">
          <h2 className="mb-3 font-bold text-brand-900">Per-listing breakdown</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="text-left text-xs uppercase text-slate-400"><th className="py-2">Listing</th><th>Status</th><th>Views</th><th>Interested buyers</th></tr></thead>
              <tbody>{a.listings.map((l) => (
                <tr key={l.id} className="border-t border-slate-50"><td className="py-2"><Link to={`/product/${l.id}`} className="font-medium hover:text-brand-700">{l.title}</Link></td><td><StatusBadge status={l.status} /></td><td>{l.views}</td><td>{l.interested}</td></tr>
              ))}</tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
