import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Eye, Heart, MessageCircle, Handshake, Pencil, Trash2, Users, PlusCircle } from 'lucide-react'
import api, { errMsg } from '../services/api'
import useFetch from '../hooks/useFetch'
import { useToast } from '../context/ToastContext'
import { Avatar, Empty, ErrorBox, Modal, PageHeader, Spinner, StatusBadge } from '../components/ui'
import { ProductImage } from '../components/ProductCard'
import { inr } from '../utils/format'

const tabs = ['all', 'active', 'reserved', 'sold']

export default function MyListings() {
  const [tab, setTab] = useState('all')
  const { data, loading, error, reload } = useFetch('/my/products', { params: tab === 'all' ? {} : { status: tab } })
  const toast = useToast()
  const [interestFor, setInterestFor] = useState(null)
  const [interested, setInterested] = useState([])

  const act = async (fn, msg) => { try { await fn(); toast.success(msg); reload() } catch (e) { toast.error(errMsg(e)) } }
  const setStatus = (id, status) => act(() => api.patch(`/products/${id}/status`, { status }), `Marked as ${status}`)
  const del = (p) => { if (confirm(`Delete "${p.title}"?`)) act(() => api.delete(`/products/${p.id}`), 'Listing deleted') }
  const showInterested = async (p) => {
    try { const { data } = await api.get(`/products/${p.id}/interested`); setInterested(data.items); setInterestFor(p) } catch (e) { toast.error(errMsg(e)) }
  }

  return (
    <div>
      <PageHeader title="My listings" subtitle="Manage what you're selling." action={<Link to="/create" className="btn-mint"><PlusCircle className="h-4 w-4" />New listing</Link>} />
      <div className="mb-5 flex gap-1 rounded-xl bg-white p-1 shadow-card sm:w-fit">
        {tabs.map((t) => <button key={t} onClick={() => setTab(t)} className={`rounded-lg px-4 py-1.5 text-sm font-semibold capitalize transition ${tab === t ? 'bg-brand-700 text-white' : 'text-slate-500 hover:text-brand-700'}`}>{t}</button>)}
      </div>
      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading ? <Spinner /> : !data?.items?.length ? <Empty title="No listings here" hint="Post something you no longer need."><Link to="/create" className="btn-primary">Create listing</Link></Empty> : (
        <div className="space-y-4">
          {data.items.map((p) => (
            <div key={p.id} className="card flex flex-col gap-4 p-4 sm:flex-row">
              <Link to={`/product/${p.id}`} className="h-32 w-full shrink-0 overflow-hidden rounded-xl sm:w-44"><ProductImage product={p} className="h-full w-full" /></Link>
              <div className="flex-1">
                <div className="flex items-start justify-between gap-2">
                  <div><Link to={`/product/${p.id}`} className="font-semibold hover:text-brand-700">{p.title}</Link><p className="text-lg font-extrabold text-brand-700">{inr(p.pricePaise)}</p></div>
                  <StatusBadge status={p.status} />
                </div>
                <div className="mt-2 flex flex-wrap gap-4 text-xs text-slate-500">
                  <span className="flex items-center gap-1"><Eye className="h-3.5 w-3.5" />{p.views} views</span>
                  <span className="flex items-center gap-1"><Heart className="h-3.5 w-3.5" />{p.wishlisted} saved</span>
                  <span className="flex items-center gap-1"><Handshake className="h-3.5 w-3.5" />{p.offers} offers</span>
                  <span className="flex items-center gap-1"><MessageCircle className="h-3.5 w-3.5" />{p.chats} chats</span>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  {p.status !== 'sold' && <Link to={`/edit/${p.id}`} className="btn-ghost px-3 py-1.5"><Pencil className="h-3.5 w-3.5" />Edit</Link>}
                  <button className="btn-ghost px-3 py-1.5" onClick={() => showInterested(p)}><Users className="h-3.5 w-3.5" />Interested</button>
                  {p.status === 'active' && <button className="btn-ghost px-3 py-1.5" onClick={() => setStatus(p.id, 'reserved')}>Mark reserved</button>}
                  {p.status === 'reserved' && <button className="btn-ghost px-3 py-1.5" onClick={() => setStatus(p.id, 'active')}>Re-list</button>}
                  {(p.status === 'active' || p.status === 'reserved') && <button className="btn-mint px-3 py-1.5" onClick={() => setStatus(p.id, 'sold')}>Mark sold</button>}
                  {p.status !== 'sold' && <button className="btn-danger px-3 py-1.5" onClick={() => del(p)}><Trash2 className="h-3.5 w-3.5" />Delete</button>}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      <Modal open={!!interestFor} onClose={() => setInterestFor(null)} title={`Interested in "${interestFor?.title}"`}>
        {!interested.length ? <p className="text-sm text-slate-500">No one has shown interest yet.</p> : (
          <ul className="space-y-3">{interested.map((u) => (
            <li key={u.id}><Link to={`/profile/${u.id}`} className="flex items-center gap-3 rounded-xl p-1 hover:bg-slate-50"><Avatar user={u} /><div><p className="text-sm font-semibold">{u.name}</p><p className="text-xs text-slate-500">{u.department}</p></div></Link></li>
          ))}</ul>
        )}
      </Modal>
    </div>
  )
}
