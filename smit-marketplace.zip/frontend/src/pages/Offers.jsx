import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Check, Loader2, Undo2, X } from 'lucide-react'
import api, { errMsg } from '../services/api'
import useFetch from '../hooks/useFetch'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { Avatar, Empty, ErrorBox, Modal, PageHeader, Spinner, StatusBadge } from '../components/ui'
import { ProductImage } from '../components/ProductCard'
import { fmtTime, inr } from '../utils/format'

function History({ t, sellerName, buyerName }) {
  const rows = [{ ...t, history: undefined }, ...(t.history || [])]
  return (
    <ol className="mt-3 space-y-1.5 border-l-2 border-slate-100 pl-4">
      {rows.map((o) => (
        <li key={o.id} className="text-xs text-slate-500">
          <span className="font-semibold text-slate-700">{o.fromSeller ? sellerName : buyerName}</span> {o.fromSeller ? 'countered' : 'offered'} <b>{inr(o.offeredPricePaise)}</b>
          {o.message && <> — “{o.message}”</>} · {fmtTime(o.createdAt)} · <StatusBadge status={o.status} />
        </li>
      ))}
    </ol>
  )
}

export default function Offers() {
  const { user } = useAuth()
  const toast = useToast()
  const [tab, setTab] = useState('received')
  const recv = useFetch('/offers/received', { interval: 20000 })
  const sent = useFetch('/offers/sent', { interval: 20000 })
  const [counter, setCounter] = useState(null)
  const [cp, setCp] = useState({ price: '', message: '' })
  const [busy, setBusy] = useState(false)

  const refresh = () => { recv.reload(); sent.reload() }
  const call = async (fn, msg) => { setBusy(true); try { await fn(); toast.success(msg); refresh() } catch (e) { toast.error(errMsg(e)); refresh() } finally { setBusy(false) } }
  const respond = (id, action, extra = {}) => call(() => api.patch(`/offers/${id}/respond`, { action, ...extra }), action === 'accept' ? 'Offer accepted — listing reserved' : 'Offer rejected')

  // latest actionable row in a thread
  const live = (t) => [...(t.history || []), t].reverse().find((o) => o.status === 'pending')
  const cur = tab === 'received' ? recv : sent
  const list = cur.data?.items || []

  return (
    <div>
      <PageHeader title="Offers & negotiations" subtitle="Track every price discussion in one place." />
      <div className="mb-5 flex gap-1 rounded-xl bg-white p-1 shadow-card sm:w-fit">
        {[['received', 'Received (as seller)'], ['sent', 'Sent (as buyer)']].map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={`rounded-lg px-4 py-1.5 text-sm font-semibold transition ${tab === k ? 'bg-brand-700 text-white' : 'text-slate-500 hover:text-brand-700'}`}>{l}</button>
        ))}
      </div>
      {cur.error && <ErrorBox message={cur.error} onRetry={cur.reload} />}
      {cur.loading ? <Spinner /> : !list.length ? <Empty title={tab === 'received' ? 'No offers received yet' : "You haven't made any offers"} hint={tab === 'sent' ? 'Open a negotiable listing and tap “Make offer”.' : undefined} /> : (
        <div className="space-y-4">
          {list.map((t) => {
            const p = t.product
            const active = live(t)
            const sellerName = tab === 'received' ? 'You' : p?.seller?.name?.split(' ')[0] || 'Seller'
            const buyerName = tab === 'received' ? t.buyer?.name?.split(' ')[0] || 'Buyer' : 'You'
            const finalStatus = t.status === 'countered' && !active ? 'countered' : t.status
            return (
              <div key={t.id} className="card p-4">
                <div className="flex gap-4">
                  <Link to={`/product/${t.productId}`} className="h-20 w-24 shrink-0 overflow-hidden rounded-xl"><ProductImage product={p} className="h-full w-full" /></Link>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <Link to={`/product/${t.productId}`} className="font-semibold hover:text-brand-700">{p?.title}</Link>
                        <p className="text-xs text-slate-500">Listed {inr(p?.pricePaise)}{tab === 'received' && t.buyer && <> · from <Link to={`/profile/${t.buyerId}`} className="font-medium text-brand-600">{t.buyer.name}</Link></>}</p>
                      </div>
                      <StatusBadge status={finalStatus} />
                    </div>
                    <History t={t} sellerName={sellerName} buyerName={buyerName} />
                  </div>
                </div>

                {active && tab === 'received' && !active.fromSeller && (
                  <div className="mt-4 flex flex-wrap gap-2 border-t border-slate-100 pt-3">
                    <button disabled={busy} className="btn-mint px-3 py-1.5" onClick={() => respond(active.id, 'accept')}><Check className="h-4 w-4" />Accept {inr(active.offeredPricePaise)}</button>
                    <button disabled={busy} className="btn-ghost px-3 py-1.5" onClick={() => { setCounter(active); setCp({ price: '', message: '' }) }}>Counter</button>
                    <button disabled={busy} className="btn-danger px-3 py-1.5" onClick={() => respond(active.id, 'reject')}><X className="h-4 w-4" />Reject</button>
                  </div>
                )}
                {active && tab === 'sent' && active.fromSeller && (
                  <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-3">
                    <span className="text-sm text-slate-600">Seller countered with <b>{inr(active.offeredPricePaise)}</b></span>
                    <button disabled={busy} className="btn-mint px-3 py-1.5" onClick={() => respond(active.id, 'accept')}><Check className="h-4 w-4" />Accept</button>
                    <button disabled={busy} className="btn-danger px-3 py-1.5" onClick={() => respond(active.id, 'reject')}>Decline</button>
                  </div>
                )}
                {tab === 'sent' && ['pending', 'countered'].includes(t.status) && (
                  <div className="mt-3"><button disabled={busy} className="flex items-center gap-1 text-xs font-semibold text-slate-400 hover:text-red-500" onClick={() => call(() => api.patch(`/offers/${t.id}/withdraw`), 'Offer withdrawn')}><Undo2 className="h-3.5 w-3.5" />Withdraw offer</button></div>
                )}
                {t.status === 'accepted' && <p className="mt-3 text-sm text-mint-700">Deal agreed! Continue in <Link to="/transactions" className="font-semibold underline">Exchanges</Link> to arrange pickup.</p>}
              </div>
            )
          })}
        </div>
      )}

      <Modal open={!!counter} onClose={() => setCounter(null)} title="Counter-offer">
        <form className="space-y-4" onSubmit={async (e) => {
          e.preventDefault()
          setBusy(true)
          try { await api.patch(`/offers/${counter.id}/respond`, { action: 'counter', price: Number(cp.price), message: cp.message }); toast.success('Counter-offer sent'); setCounter(null); refresh() }
          catch (err) { toast.error(errMsg(err)) } finally { setBusy(false) }
        }}>
          <p className="text-sm text-slate-500">Buyer offered <b>{counter && inr(counter.offeredPricePaise)}</b>. Suggest a price in between.</p>
          <div><label className="label">Your counter (₹)</label><input className="input" type="number" min="1" required value={cp.price} onChange={(e) => setCp({ ...cp, price: e.target.value })} /></div>
          <div><label className="label">Message</label><textarea className="input" rows={2} maxLength={500} value={cp.message} onChange={(e) => setCp({ ...cp, message: e.target.value })} /></div>
          <button className="btn-primary w-full" disabled={busy}>{busy && <Loader2 className="h-4 w-4 animate-spin" />}Send counter-offer</button>
        </form>
      </Modal>
    </div>
  )
}
