import { useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { BadgeCheck, Camera, Loader2, Pencil } from 'lucide-react'
import api, { errMsg } from '../services/api'
import useFetch from '../hooks/useFetch'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { Avatar, Empty, ErrorBox, Modal, Spinner, Stars } from '../components/ui'
import ProductCard from '../components/ProductCard'
import { timeAgo } from '../utils/format'

export default function Profile() {
  const { id } = useParams()
  const { user, setUser } = useAuth()
  const toast = useToast()
  const { data, loading, error, reload } = useFetch(`/users/${id}/reviews`)
  const [editing, setEditing] = useState(false)
  const [f, setF] = useState({})
  const [file, setFile] = useState(null)
  const [busy, setBusy] = useState(false)

  if (loading) return <Spinner />
  if (error) return <ErrorBox message={error} onRetry={reload} />
  const u = data.user
  const mine = user.id === u.id

  const openEdit = () => { setF({ name: user.name, college: user.college, department: user.department, year: String(user.year) }); setFile(null); setEditing(true) }
  const save = async (e) => {
    e.preventDefault()
    setBusy(true)
    try {
      const fd = new FormData()
      Object.entries(f).forEach(([k, v]) => fd.append(k, v))
      if (file) fd.append('profileImage', file)
      const { data: updated } = await api.put('/auth/profile', fd)
      setUser(updated)
      toast.success('Profile updated')
      setEditing(false)
      reload()
    } catch (err) { toast.error(errMsg(err)) } finally { setBusy(false) }
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <div className="card flex flex-col items-center gap-5 p-6 sm:flex-row">
        <Avatar user={u} size="h-24 w-24 text-3xl" />
        <div className="flex-1 text-center sm:text-left">
          <h1 className="flex items-center justify-center gap-2 text-2xl font-extrabold text-brand-900 sm:justify-start">{u.name}{u.verified && <BadgeCheck className="h-5 w-5 text-mint-500" title="Verified student" />}</h1>
          <p className="text-sm text-slate-500">{u.department}{u.college && ` · ${u.college}`} · Year {u.year}</p>
          <div className="mt-2 flex items-center justify-center gap-2 sm:justify-start">
            <Stars value={data.avgRating} />
            <span className="text-sm text-slate-500">{data.reviewCount ? `${data.avgRating.toFixed(1)} · ${data.reviewCount} review${data.reviewCount > 1 ? 's' : ''}` : 'No reviews yet'}</span>
          </div>
          <p className="mt-1 text-xs text-slate-400">{data.completedSales} completed sale{data.completedSales !== 1 && 's'} · member since {new Date(u.createdAt).toLocaleDateString('en-IN', { month: 'short', year: 'numeric' })}</p>
        </div>
        {mine && <button onClick={openEdit} className="btn-ghost"><Pencil className="h-4 w-4" />Edit profile</button>}
      </div>

      <section>
        <h2 className="mb-3 text-lg font-bold text-brand-900">Reviews</h2>
        {!data.reviews.length ? <Empty title="No reviews yet" /> : (
          <div className="space-y-3">{data.reviews.map((r) => (
            <div key={r.id} className="card p-4">
              <div className="flex items-center justify-between"><div className="flex items-center gap-2"><Avatar user={r.reviewer} size="h-8 w-8" /><Link to={`/profile/${r.reviewerId}`} className="text-sm font-semibold hover:text-brand-700">{r.reviewer?.name}</Link></div><Stars value={r.rating} /></div>
              {r.comment && <p className="mt-2 text-sm text-slate-600">{r.comment}</p>}
              <p className="mt-1 text-xs text-slate-400">{timeAgo(r.createdAt)}</p>
            </div>
          ))}</div>
        )}
      </section>

      {data.listings.length > 0 && (
        <section>
          <h2 className="mb-3 text-lg font-bold text-brand-900">Active listings</h2>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{data.listings.map((p) => <ProductCard key={p.id} product={p} />)}</div>
        </section>
      )}

      <Modal open={editing} onClose={() => setEditing(false)} title="Edit profile">
        <form onSubmit={save} className="space-y-3">
          <div><label className="label">Name</label><input className="input" required value={f.name || ''} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
          <div><label className="label">College</label><input className="input" value={f.college || ''} onChange={(e) => setF({ ...f, college: e.target.value })} /></div>
          <div><label className="label">Department</label><input className="input" value={f.department || ''} onChange={(e) => setF({ ...f, department: e.target.value })} /></div>
          <div><label className="label">Year</label><select className="input" value={f.year || '1'} onChange={(e) => setF({ ...f, year: e.target.value })}>{[1, 2, 3, 4, 5, 6].map((y) => <option key={y} value={y}>Year {y}</option>)}</select></div>
          <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-dashed border-slate-300 p-3 text-sm text-slate-500"><Camera className="h-4 w-4" />{file ? file.name : 'Change profile picture'}<input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={(e) => setFile(e.target.files[0])} /></label>
          <button className="btn-primary w-full" disabled={busy}>{busy && <Loader2 className="h-4 w-4 animate-spin" />}Save</button>
        </form>
      </Modal>
    </div>
  )
}
