import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { ImagePlus, Loader2, X } from 'lucide-react'
import api, { errMsg } from '../services/api'
import useFetch from '../hooks/useFetch'
import { useToast } from '../context/ToastContext'
import { ErrorBox, PageHeader, Spinner } from '../components/ui'

const MAX_IMAGES = 6

export default function ListingForm() {
  const { id } = useParams()
  const editing = !!id
  const nav = useNavigate()
  const toast = useToast()
  const { data: meta } = useFetch('/categories')
  const { data: existing, loading, error } = useFetch(`/products/${id}`, { enabled: editing })
  const [f, setF] = useState({ title: '', description: '', price: '', categoryId: '', condition: 'Good', negotiable: true, pickupLocation: '' })
  const [oldImgs, setOldImgs] = useState([])
  const [removed, setRemoved] = useState([])
  const [files, setFiles] = useState([])
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')

  useEffect(() => {
    if (!existing) return
    const p = existing.product
    if (!existing.isOwner) { nav('/marketplace'); return }
    setF({ title: p.title, description: p.description, price: String(p.pricePaise / 100), categoryId: String(p.categoryId), condition: p.condition, negotiable: p.negotiable, pickupLocation: p.pickupLocation })
    setOldImgs(p.images || [])
  }, [existing, nav])

  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value })
  const total = oldImgs.filter((i) => !removed.includes(i.id)).length + files.length

  const addFiles = (e) => {
    const picked = Array.from(e.target.files)
    e.target.value = ''
    const ok = picked.filter((x) => ['image/jpeg', 'image/png', 'image/webp', 'image/gif'].includes(x.type) && x.size <= 5 * 1024 * 1024)
    if (ok.length !== picked.length) toast.error('Only JPG/PNG/WEBP/GIF images up to 5 MB are accepted')
    setFiles([...files, ...ok].slice(0, MAX_IMAGES - (total - files.length)))
  }

  const submit = async (e) => {
    e.preventDefault()
    setErr('')
    if (total < 1) return setErr('Add at least one image')
    setBusy(true)
    try {
      const fd = new FormData()
      Object.entries(f).forEach(([k, v]) => fd.append(k, v))
      files.forEach((x) => fd.append('images', x))
      if (editing) fd.append('removeImages', removed.join(','))
      const { data } = editing ? await api.put(`/products/${id}`, fd) : await api.post('/products', fd)
      toast.success(editing ? 'Listing updated' : 'Listing published')
      nav(`/product/${data.id}`)
    } catch (e2) { setErr(errMsg(e2)) } finally { setBusy(false) }
  }

  if (editing && loading) return <Spinner />
  if (editing && error) return <ErrorBox message={error} />

  return (
    <form onSubmit={submit} className="mx-auto max-w-3xl">
      <PageHeader title={editing ? 'Edit listing' : 'Create a listing'} subtitle="Great photos and an honest description sell faster." />
      <div className="card space-y-5 p-6">
        <div><label className="label">Title</label><input className="input" required minLength={3} maxLength={150} value={f.title} onChange={set('title')} placeholder="e.g. Engineering Mathematics – Kreyszig" /></div>
        <div><label className="label">Description</label><textarea className="input" rows={4} maxLength={3000} value={f.description} onChange={set('description')} /></div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><label className="label">Price (₹)</label><input className="input" type="number" min="1" step="0.01" required value={f.price} onChange={set('price')} /></div>
          <div><label className="label">Category</label>
            <select className="input" required value={f.categoryId} onChange={set('categoryId')}><option value="">Select…</option>{meta?.categories?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
          <div><label className="label">Condition</label>
            <select className="input" value={f.condition} onChange={set('condition')}>{meta?.conditions?.map((c) => <option key={c}>{c}</option>)}</select></div>
          <div><label className="label">Campus pickup location</label><input className="input" required maxLength={200} value={f.pickupLocation} onChange={set('pickupLocation')} placeholder="e.g. Central Library entrance" /></div>
        </div>
        <label className="flex cursor-pointer items-center gap-3 rounded-xl bg-mint-50 p-3 text-sm">
          <input type="checkbox" className="h-4 w-4 accent-mint-600" checked={f.negotiable} onChange={set('negotiable')} />
          <span><b>Negotiable</b> — allow buyers to send price offers</span>
        </label>
        <div>
          <label className="label">Images ({total}/{MAX_IMAGES})</label>
          <div className="flex flex-wrap gap-3">
            {oldImgs.filter((i) => !removed.includes(i.id)).map((im) => (
              <div key={im.id} className="group relative h-24 w-24 overflow-hidden rounded-xl">
                <img src={im.imagePath} className="h-full w-full object-cover" alt="" />
                <button type="button" onClick={() => setRemoved([...removed, im.id])} className="absolute right-1 top-1 rounded-full bg-black/60 p-1 text-white"><X className="h-3 w-3" /></button>
              </div>
            ))}
            {files.map((x, i) => (
              <div key={i} className="relative h-24 w-24 overflow-hidden rounded-xl ring-2 ring-mint-400">
                <img src={URL.createObjectURL(x)} className="h-full w-full object-cover" alt="" />
                <button type="button" onClick={() => setFiles(files.filter((_, j) => j !== i))} className="absolute right-1 top-1 rounded-full bg-black/60 p-1 text-white"><X className="h-3 w-3" /></button>
              </div>
            ))}
            {total < MAX_IMAGES && (
              <label className="flex h-24 w-24 cursor-pointer flex-col items-center justify-center gap-1 rounded-xl border-2 border-dashed border-slate-300 text-xs text-slate-500 transition hover:border-brand-500 hover:text-brand-600">
                <ImagePlus className="h-5 w-5" />Add
                <input type="file" multiple accept="image/jpeg,image/png,image/webp,image/gif" className="hidden" onChange={addFiles} />
              </label>
            )}
          </div>
        </div>
        {err && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">{err}</p>}
        <div className="flex gap-3">
          <button type="button" className="btn-ghost" onClick={() => nav(-1)}>Cancel</button>
          <button className="btn-primary flex-1" disabled={busy}>{busy && <Loader2 className="h-4 w-4 animate-spin" />}{editing ? 'Save changes' : 'Publish listing'}</button>
        </div>
      </div>
    </form>
  )
}
