import { useState } from 'react'
import { Link } from 'react-router-dom'
import { CheckCircle2, Loader2, MessageCircle, Star, XCircle } from 'lucide-react'
import api, { errMsg } from '../services/api'
import useFetch from '../hooks/useFetch'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { Empty, ErrorBox, Modal, PageHeader, Spinner, Stars, StatusBadge } from '../components/ui'
import { ProductImage } from '../components/ProductCard'
import { fmtTime, inr } from '../utils/format'

const steps = ['requested', 'reserved', 'completed']

export default function Transactions() {
  const { user } = useAuth()
  const toast = useToast()
  const [role, setRole] = useState('all')
  const { data, loading, error, reload } = useFetch('/transactions', { params: role === 'all' ? {} : { role }, interval: 20000 })
  const [busy, setBusy] = useState(false)
  const [review, setReview] = useState(null)
  const [rv, setRv] = useState({ rating: 5, comment: '' })

  const setStatus = async (id, status, msg) => {
    setBusy(true)
    try { await api.patch(`/transactions/${id}/status`, { status }); toast.success(msg); reload() } catch (e) { toast.error(errMsg(e)); reload() } finally { setBusy(false) }
  }
  const submitReview = async (e) => {
    e.preventDefault()
    setBusy(true)
    try { await api.post('/reviews', { transactionId: review.id, ...rv }); toast.success('Review submitted'); setReview(null); reload() }
    catch (err) { toast.error(errMsg(err)) } finally { setBusy(false) }
  }

  return (
    <div>
      <PageHeader title="Exchanges" subtitle="Purchase requests, reservations and completed handovers." />
      <div className="mb-5 flex gap-1 rounded-xl bg-white p-1 shadow-card sm:w-fit">
        {[['all', 'All'], ['buyer', 'Buying'], ['seller', 'Selling']].map(([k, l]) => (
          <button key={k} onClick={() => setRole(k)} className={`rounded-lg px-4 py-1.5 text-sm font-semibold ${role === k ? 'bg-brand-700 text-white' : 'text-slate-500 hover:text-brand-700'}`}>{l}</button>
        ))}
      </div>
      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading ? <Spinner /> : !data?.items?.length ? <Empty title="No exchanges yet" hint="Send a purchase request or accept an offer to start one."><Link to="/marketplace" className="btn-primary">Browse marketplace</Link></Empty> : (
        <div className="space-y-4">
          {data.items.map((t) => {
            const isSeller = t.sellerId === user.id
            const other = isSeller ? t.buyer : t.seller
            const idx = steps.indexOf(t.status)
            const dead = ['rejected', 'cancelled'].includes(t.status)
            return (
              <div key={t.id} className="card p-4">
                <div className="flex gap-4">
                  <Link to={`/product/${t.productId}`} className="h-20 w-24 shrink-0 overflow-hidden rounded-xl"><ProductImage product={t.product} className="h-full w-full" /></Link>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <Link to={`/product/${t.productId}`} className="font-semibold hover:text-brand-700">{t.product?.title}</Link>
                        <p className="text-lg font-extrabold text-brand-700">{inr(t.finalPricePaise)}</p>
                        <p className="text-xs text-slate-500">{isSeller ? 'Buyer' : 'Seller'}: <Link to={`/profile/${other.id}`} className="font-medium text-brand-600">{other.name}</Link> · {fmtTime(t.createdAt)}</p>
                      </div>
                      <StatusBadge status={t.status} />
                    </div>
                    {!dead && (
                      <div className="mt-3 flex items-center gap-2">
                        {steps.map((s, i) => (
                          <div key={s} className="flex flex-1 items-center gap-2">
                            <span className={`h-2 flex-1 rounded-full ${i <= idx ? 'bg-mint-500' : 'bg-slate-200'}`} />
                            <span className={`text-[10px] font-semibold uppercase ${i <= idx ? 'text-mint-700' : 'text-slate-400'}`}>{s}</span>
                          </div>
                        ))}
                      </div>
                    )}
                    {t.status === 'reserved' && <p className="mt-3 rounded-lg bg-mint-50 px-3 py-2 text-xs text-mint-700">Arrange campus pickup at <b>{t.product?.pickupLocation}</b>. The seller marks the item as handed over once done.</p>}
                  </div>
                </div>

                <div className="mt-4 flex flex-wrap gap-2 border-t border-slate-100 pt-3">
                  {isSeller && t.status === 'requested' && <>
                    <button disabled={busy} className="btn-mint px-3 py-1.5" onClick={() => setStatus(t.id, 'accepted', 'Request accepted — listing reserved')}><CheckCircle2 className="h-4 w-4" />Accept</button>
                    <button disabled={busy} className="btn-danger px-3 py-1.5" onClick={() => setStatus(t.id, 'rejected', 'Request rejected')}><XCircle className="h-4 w-4" />Reject</button>
                  </>}
                  {!isSeller && t.status === 'requested' && <button disabled={busy} className="btn-danger px-3 py-1.5" onClick={() => setStatus(t.id, 'cancelled', 'Request cancelled')}>Cancel request</button>}
                  {isSeller && t.status === 'reserved' && <button disabled={busy} className="btn-primary px-3 py-1.5" onClick={() => setStatus(t.id, 'completed', 'Marked as sold — exchange complete')}>{busy && <Loader2 className="h-4 w-4 animate-spin" />}Mark as sold / handed over</button>}
                  {t.status === 'reserved' && <button disabled={busy} className="btn-danger px-3 py-1.5" onClick={() => confirm('Cancel this exchange? The listing becomes available again.') && setStatus(t.id, 'cancelled', 'Exchange cancelled')}>Cancel exchange</button>}
                  {t.status === 'completed' && !t.myReviewed && <button className="btn-mint px-3 py-1.5" onClick={() => { setReview(t); setRv({ rating: 5, comment: '' }) }}><Star className="h-4 w-4" />Leave a review</button>}
                  {t.status === 'completed' && t.myReviewed && <span className="flex items-center gap-1 text-xs text-slate-500"><CheckCircle2 className="h-4 w-4 text-mint-500" />You reviewed this exchange</span>}
                  {!dead && t.status !== 'completed' && !isSeller && <Link to={`/product/${t.productId}`} className="btn-ghost px-3 py-1.5"><MessageCircle className="h-4 w-4" />Message seller</Link>}
                </div>
              </div>
            )
          })}
        </div>
      )}

      <Modal open={!!review} onClose={() => setReview(null)} title={`Rate ${review && (review.sellerId === user.id ? review.buyer?.name : review.seller?.name)}`}>
        <form onSubmit={submitReview} className="space-y-4">
          <div className="flex justify-center py-1"><Stars value={rv.rating} size="h-8 w-8" onChange={(n) => setRv({ ...rv, rating: n })} /></div>
          <textarea className="input" rows={3} maxLength={500} placeholder="How was the exchange? (optional)" value={rv.comment} onChange={(e) => setRv({ ...rv, comment: e.target.value })} />
          <button className="btn-primary w-full" disabled={busy}>Submit review</button>
        </form>
      </Modal>
    </div>
  )
}
