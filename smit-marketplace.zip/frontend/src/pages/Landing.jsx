import { Link } from 'react-router-dom'
import { ArrowRight, BookOpen, Handshake, MessageSquare, ShieldCheck, Tag, Laptop, Bike, Sofa, Shirt, PenTool, BedDouble } from 'lucide-react'
import useFetch from '../hooks/useFetch'
import ProductCard from '../components/ProductCard'
import { Spinner } from '../components/ui'
import { useAuth } from '../context/AuthContext'

const cats = [
  { n: 'Books and Academic Materials', i: BookOpen }, { n: 'Electronics and Gadgets', i: Laptop },
  { n: 'Hostel and Room Essentials', i: BedDouble }, { n: 'Clothing and Accessories', i: Shirt },
  { n: 'Cycles and Sports Equipment', i: Bike }, { n: 'Furniture', i: Sofa }, { n: 'Stationery', i: PenTool },
]

export default function Landing() {
  const { user } = useAuth()
  const { data, loading } = useFetch('/products', { params: { pageSize: 4, sort: 'newest' } })
  const { data: meta } = useFetch('/categories')
  const catId = (name) => meta?.categories?.find((c) => c.name === name)?.id

  return (
    <div className="space-y-16">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand-900 via-brand-700 to-brand-600 px-6 py-16 text-white shadow-lift sm:px-12 sm:py-20">
        <div className="absolute -right-20 -top-20 h-72 w-72 rounded-full bg-mint-400/20 blur-3xl" />
        <div className="relative max-w-2xl">
          <span className="badge bg-mint-400/20 text-mint-200">For students, by students</span>
          <h1 className="mt-4 text-4xl font-extrabold leading-tight sm:text-5xl">Your campus, your marketplace.</h1>
          <p className="mt-4 text-lg text-brand-100">Buy, sell and exchange second-hand books, gadgets, cycles and room essentials with verified students — negotiate prices, chat, and meet on campus.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/marketplace" className="btn bg-white text-brand-800 hover:bg-brand-50">Browse listings <ArrowRight className="h-4 w-4" /></Link>
            <Link to={user ? '/create' : '/register'} className="btn-mint">{user ? 'Sell an item' : 'Join your campus'}</Link>
          </div>
        </div>
      </section>

      <section>
        <h2 className="mb-5 text-xl font-bold text-brand-900">Shop by category</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7">
          {cats.map(({ n, i: Icon }) => (
            <Link key={n} to={`/marketplace?category=${catId(n) || ''}`} className="card flex flex-col items-center gap-2 p-4 text-center text-xs font-semibold text-slate-700 transition hover:-translate-y-1 hover:shadow-lift">
              <span className="rounded-xl bg-mint-50 p-3 text-mint-600"><Icon className="h-5 w-5" /></span>{n}
            </Link>
          ))}
        </div>
      </section>

      <section>
        <div className="mb-5 flex items-center justify-between">
          <h2 className="text-xl font-bold text-brand-900">Fresh on campus</h2>
          <Link to="/marketplace" className="text-sm font-semibold text-brand-600 hover:underline">View all</Link>
        </div>
        {loading ? <Spinner /> : data?.items?.length ? (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{data.items.map((p) => <ProductCard key={p.id} product={p} />)}</div>
        ) : <p className="rounded-2xl bg-white p-8 text-center text-slate-500">No listings yet — be the first to post one!</p>}
      </section>

      <section className="grid gap-5 md:grid-cols-4">
        {[
          { i: Tag, t: 'List in minutes', d: 'Photos, price, pickup spot. Done.' },
          { i: Handshake, t: 'Negotiate fairly', d: 'Offer, counter-offer and agree on a price.' },
          { i: MessageSquare, t: 'Chat in-app', d: 'Ask questions without sharing your number.' },
          { i: ShieldCheck, t: 'Verified students', d: 'Email-verified accounts and ratings.' },
        ].map(({ i: Icon, t, d }) => (
          <div key={t} className="card p-5">
            <span className="mb-3 inline-flex rounded-xl bg-brand-50 p-2.5 text-brand-700"><Icon className="h-5 w-5" /></span>
            <h3 className="font-bold text-brand-900">{t}</h3><p className="mt-1 text-sm text-slate-500">{d}</p>
          </div>
        ))}
      </section>
    </div>
  )
}
