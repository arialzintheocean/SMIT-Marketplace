import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { Loader2, MailCheck } from 'lucide-react'
import api, { errMsg } from '../services/api'
import { useToast } from '../context/ToastContext'

export default function Register() {
  const nav = useNavigate()
  const loc = useLocation()
  const toast = useToast()
  const [step, setStep] = useState(loc.state?.verifyEmail ? 'otp' : 'form')
  const [email, setEmail] = useState(loc.state?.verifyEmail || '')
  const [devOtp, setDevOtp] = useState('')
  const [otp, setOtp] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [f, setF] = useState({ name: '', email: '', password: '', college: '', department: '', year: '1' })
  const [file, setFile] = useState(null)
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    setBusy(true)
    try {
      const fd = new FormData()
      Object.entries(f).forEach(([k, v]) => fd.append(k, v))
      if (file) fd.append('profileImage', file)
      const { data } = await api.post('/auth/register', fd)
      setEmail(data.email)
      setDevOtp(data.dev_otp || '')
      setStep('otp')
    } catch (err) { setError(errMsg(err)) } finally { setBusy(false) }
  }

  const verify = async (e) => {
    e.preventDefault()
    setError('')
    setBusy(true)
    try {
      await api.post('/auth/verify-email', { email, otp })
      toast.success('Email verified! Please log in.')
      nav('/login')
    } catch (err) { setError(errMsg(err)) } finally { setBusy(false) }
  }

  const resend = async () => {
    try {
      const { data } = await api.post('/auth/resend-otp', { email })
      setDevOtp(data.dev_otp || '')
      toast.success('A new code has been sent')
    } catch (err) { toast.error(errMsg(err)) }
  }

  if (step === 'otp') {
    return (
      <div className="card mx-auto max-w-md p-8">
        <div className="mb-4 inline-flex rounded-2xl bg-mint-50 p-3 text-mint-600"><MailCheck className="h-6 w-6" /></div>
        <h1 className="text-2xl font-extrabold text-brand-900">Verify your email</h1>
        <p className="mt-1 text-sm text-slate-500">Enter the 6-digit code sent to <b>{email}</b>.</p>
        {devOtp && (
          <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800">
            <b>Development mode:</b> SMTP isn't configured, so your code is <span className="font-mono font-bold">{devOtp}</span>
          </div>
        )}
        <form onSubmit={verify} className="mt-5 space-y-4">
          <input className="input text-center text-2xl font-bold tracking-[.5em]" maxLength={6} inputMode="numeric" value={otp} onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))} placeholder="••••••" autoFocus />
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button className="btn-primary w-full" disabled={busy || otp.length !== 6}>{busy && <Loader2 className="h-4 w-4 animate-spin" />}Verify email</button>
          <button type="button" onClick={resend} className="w-full text-sm font-semibold text-brand-600 hover:underline">Resend code</button>
        </form>
      </div>
    )
  }

  return (
    <div className="card mx-auto max-w-xl p-8">
      <h1 className="text-2xl font-extrabold text-brand-900">Join your campus marketplace</h1>
      <p className="mt-1 text-sm text-slate-500">Create a student account with your college email.</p>
      <form onSubmit={submit} className="mt-6 grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2"><label className="label">Full name</label><input className="input" required value={f.name} onChange={set('name')} /></div>
        <div className="sm:col-span-2"><label className="label">College email</label><input type="email" className="input" required value={f.email} onChange={set('email')} placeholder="you@college.edu" /></div>
        <div className="sm:col-span-2"><label className="label">Password (min 8 characters)</label><input type="password" minLength={8} className="input" required value={f.password} onChange={set('password')} /></div>
        <div><label className="label">College</label><input className="input" required value={f.college} onChange={set('college')} /></div>
        <div><label className="label">Department</label><input className="input" required value={f.department} onChange={set('department')} /></div>
        <div><label className="label">Year of study</label>
          <select className="input" value={f.year} onChange={set('year')}>{[1, 2, 3, 4, 5, 6].map((y) => <option key={y} value={y}>Year {y}</option>)}</select></div>
        <div><label className="label">Profile picture (optional)</label><input type="file" accept="image/jpeg,image/png,image/webp" className="input p-2" onChange={(e) => setFile(e.target.files[0])} /></div>
        {error && <p className="text-sm text-red-600 sm:col-span-2">{error}</p>}
        <button className="btn-primary sm:col-span-2" disabled={busy}>{busy && <Loader2 className="h-4 w-4 animate-spin" />}Create account</button>
      </form>
      <p className="mt-5 text-center text-sm text-slate-500">Already registered? <Link to="/login" className="font-semibold text-brand-600">Log in</Link></p>
    </div>
  )
}
