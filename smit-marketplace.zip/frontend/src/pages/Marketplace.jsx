import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { ChevronLeft, ChevronRight, Search, SlidersHorizontal, X } from 'lucide-react'
import useFetch from '../hooks/useFetch'
import ProductCard from '../components/ProductCard'
import { Empty, ErrorBox, Spinner } from '../components/ui'
import { useAuth } from '../context/AuthContext'
import { getRecent } from '../utils/format'

export default function Marketplace() {
  const { user } = useAuth()
  const [sp, setSp] = useSearchParams()
  const [q, setQ] = useState(sp.get('q') || '')
  const [min, setMin] = useState(sp.get('minPrice') || '')
  const [max, setMax] = useState(sp.get('maxPrice') || '')
  const [showFilters, setShowFilters] = useState(false)

  const params = useMemo(() => {
    const o = {}
    for (const k of ['q', 'category', 'minPrice', 'maxPrice', 'condition', 'negotiable', 'sort', 'page']) if (sp.get(k)) o[k] = sp.get(k)
    return o
  }, [sp])

  const { data, loading, error, reload } = useFetch('/products', { params })
  const { data: meta } = useFetch('/categories')
  const { data: wish } = useFetch('/wishlist', { enabled: !!user })
  const saved = useMemo(() => new Set((wish?.items || []).map((w) => w.productId)), [wish])
  const recentIds = useMemo(() => getRecent(), [])
  const { data: recent } = useFetch('/products/batch', { params: { ids: recentIds.join(',') }, enabled: recentIds.length > 0 })

  useEffect(() => { setQ(sp.get('q') || '') }, [sp])

  const update = (patch) => {
    const n = new URLSearchParams(sp)
    Object.entries(patch).forEach(([k, v]) => (v === '' || v === null || v === false ? n.delete(k) : n.set(k, v)))
    if (!('page' in patch)) n.delete('page')
    setSp(n)
  }
  const conds = (sp.get('condition') || '').split(',').filter(Boolean)
  const toggleCond = (c) => update({ condition: (conds.includes(c) ? conds.filter((x) => x !== c) : [...conds, c]).join(',') })
  const page = Number(sp.get('page') || 1)
  const activeFilters = ['category', 'minPrice', 'maxPrice', 'condition', 'negotiable'].some((k) => sp.get(k))

  const filters = (
    <div className="space-y-6">
      <div>
        <p className="label">Category</p>
        <div className="space-y-1">
          <button onClick={() => update({ category: '' })} className={`block w-full rounded-lg px-3 py-1.5 text-left text-sm ${!sp.get('category') ? 'bg-brand-50 font-semibold text-brand-700' : 'hover:bg-slate-50'}`}>All categories</button>
          {meta?.categories?.map((c) => (
            <button key={c.id} onClick={() => update({ category: c.id })} className={`block w-full rounded-lg px-3 py-1.5 text-left text-sm ${sp.get('category') === String(c.id) ? 'bg-brand-50 font-semibold text-brand-700' : 'hover:bg-slate-50'}`}>{c.name}</button>
          ))}
        </div>
      </div>
      <div>
        <p className="label">Price (₹)</p>
        <form className="flex items-center gap-2" onSubmit={(e) => { e.preventDefault(); update({ minPrice: min, maxPrice: max }) }}>
          <input className="input" type="number" min="0" placeholder="Min" value={min} onChange={(e) => setMin(e.target.value)} />
          <input className="input" type="number" min="0" placeholder="Max" value={max} onChange={(e) => setMax(e.target.value)} />
          <button className="btn-primary px-3">Go</button>
        </form>
      </div>
      <div>
        <p className="label">Condition</p>
        {meta?.conditions?.map((c) => (
          <label key={c} className="flex cursor-pointer items-center gap-2 py-1 text-sm">
            <input type="checkbox" className="h-4 w-4 accent-brand-700" checked={conds.includes(c)} onChange={() => toggleCond(c)} />{c}
          </label>
        ))}
      </div>
      <label className="flex cursor-pointer items-center gap-2 text-sm font-medium">
        <input type="checkbox" className="h-4 w-4 accent-mint-600" checked={sp.get('negotiable') === 'true'} onChange={(e) => update({ negotiable: e.target.checked ? 'true' : '' })} />Negotiable only
      </label>
      {activeFilters && <button onClick={() => { setMin(''); setMax(''); setSp(q ? { q } : {}) }} className="btn-ghost w-full"><X className="h-4 w-4" />Clear filters</button>}
    </div>
  )

  return (
    <div>
      <form onSubmit={(e) => { e.preventDefault(); update({ q: q.trim() }) }} className="mb-6 flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-3 h-4 w-4 text-slate-400" />
          <input className="input pl-10" placeholder="Search books, cycles, gadgets…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <select className="input w-auto" value={sp.get('sort') || 'newest'} onChange={(e) => update({ sort: e.target.value })}>
          <option value="newest">Newest</option><option value="price_asc">Price: low to high</option><option value="price_desc">Price: high to low</option>
        </select>
        <button type="button" className="btn-ghost lg:hidden" onClick={() => setShowFilters(!showFilters)}><SlidersHorizontal className="h-4 w-4" /></button>
        <button className="btn-primary">Search</button>
      </form>

      <div className="grid gap-8 lg:grid-cols-[240px_1fr]">
        <aside className={`${showFilters ? 'block' : 'hidden'} lg:block`}><div className="card p-5 lg:sticky lg:top-24">{filters}</div></aside>
        <div>
          {error && <ErrorBox message={error} onRetry={reload} />}
          {loading ? <Spinner /> : data?.items?.length ? (
            <>
              <p className="mb-4 text-sm text-slate-500">{data.total} item{data.total !== 1 && 's'} found</p>
              <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
                {data.items.map((p) => <ProductCard key={p.id} product={p} wishlisted={saved.has(p.id)} />)}
              </div>
              {data.totalPages > 1 && (
                <div className="mt-8 flex items-center justify-center gap-3">
                  <button className="btn-ghost" disabled={page <= 1} onClick={() => update({ page: page - 1 })}><ChevronLeft className="h-4 w-4" />Prev</button>
                  <span className="text-sm text-slate-500">Page {page} of {data.totalPages}</span>
                  <button className="btn-ghost" disabled={page >= data.totalPages} onClick={() => update({ page: page + 1 })}>Next<ChevronRight className="h-4 w-4" /></button>
                </div>
              )}
            </>
          ) : !error && <Empty title="No listings match your search" hint="Try different keywords or clear some filters." />}

          {recent?.items?.length > 0 && (
            <div className="mt-12">
              <h2 className="mb-4 text-lg font-bold text-brand-900">Recently viewed</h2>
              <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
                {recentIds.map((id) => recent.items.find((p) => p.id === id)).filter(Boolean).map((p) => <ProductCard key={p.id} product={p} wishlisted={saved.has(p.id)} />)}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
