import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { Loader2 } from 'lucide-react'
import api, { errMsg } from '../services/api'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const { login } = useAuth()
  const nav = useNavigate()
  const loc = useLocation()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    setBusy(true)
    try {
      const u = await login(email, password)
      nav(loc.state?.from || (u.role === 'admin' ? '/admin' : '/dashboard'), { replace: true })
    } catch (err) {
      if (err.response?.data?.needsVerification) {
        try { await api.post('/auth/resend-otp', { email }) } catch {}
        nav('/register', { state: { verifyEmail: email } })
        return
      }
      setError(errMsg(err))
    } finally { setBusy(false) }
  }

  return (
    <div className="card mx-auto max-w-md p-8">
      <h1 className="text-2xl font-extrabold text-brand-900">Welcome back</h1>
      <p className="mt-1 text-sm text-slate-500">Log in to buy, sell and negotiate on campus.</p>
      <form onSubmit={submit} className="mt-6 space-y-4">
        <div><label className="label">Email</label><input type="email" className="input" required value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <div><label className="label">Password</label><input type="password" className="input" required value={password} onChange={(e) => setPassword(e.target.value)} /></div>
        {error && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">{error}</p>}
        <button className="btn-primary w-full" disabled={busy}>{busy && <Loader2 className="h-4 w-4 animate-spin" />}Log in</button>
      </form>
      <p className="mt-5 text-center text-sm text-slate-500">New here? <Link to="/register" className="font-semibold text-brand-600">Create an account</Link></p>
    </div>
  )
}
