import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Ban, CheckCircle2, Flag, Package, PackageCheck, Search, Trash2, Users, Handshake, RotateCcw } from 'lucide-react'
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import api, { errMsg } from '../services/api'
import useFetch from '../hooks/useFetch'
import { useToast } from '../context/ToastContext'
import { Avatar, Empty, ErrorBox, PageHeader, Spinner, StatusBadge } from '../components/ui'
import { fmtTime, inr, timeAgo } from '../utils/format'

const Stat = ({ icon: Icon, label, value, tone }) => (
  <div className="card p-5">
    <span className={`mb-3 inline-flex rounded-xl p-2.5 ${tone === 'red' ? 'bg-red-50 text-red-500' : tone === 'mint' ? 'bg-mint-50 text-mint-600' : 'bg-brand-50 text-brand-700'}`}><Icon className="h-5 w-5" /></span>
    <p className="text-2xl font-extrabold text-brand-900">{value}</p><p className="text-sm text-slate-500">{label}</p>
  </div>
)

function Overview() {
  const { data, loading, error, reload } = useFetch('/admin/dashboard', { interval: 30000 })
  if (loading) return <Spinner />
  if (error) return <ErrorBox message={error} onRetry={reload} />
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        <Stat icon={Users} label="Registered students" value={data.totalStudents} />
        <Stat icon={Package} label="Active listings" value={data.activeListings} tone="mint" />
        <Stat icon={PackageCheck} label="Sold products" value={data.soldProducts} />
        <Stat icon={Flag} label="Pending reports" value={data.pendingReports} tone="red" />
        <Stat icon={Handshake} label="Completed exchanges" value={data.completedExchanges} tone="mint" />
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="card p-6">
          <h2 className="mb-4 font-bold text-brand-900">Most popular categories</h2>
          {data.popularCategories?.length ? (
            <div className="h-72"><ResponsiveContainer>
              <BarChart data={data.popularCategories} layout="vertical" margin={{ left: 40 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11 }} /><YAxis type="category" dataKey="name" width={150} tick={{ fontSize: 11 }} />
                <Tooltip /><Bar dataKey="count" name="Listings" fill="#10b981" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer></div>
          ) : <p className="py-10 text-center text-sm text-slate-400">No data yet.</p>}
        </div>
        <div className="card p-6">
          <h2 className="mb-4 font-bold text-brand-900">Platform activity</h2>
          <div className="space-y-4 text-sm">
            <div><p className="label">Newest students</p>{data.activity.newUsers.map((u) => <p key={u.id} className="flex justify-between py-0.5"><span>{u.name}</span><span className="text-xs text-slate-400">{timeAgo(u.createdAt)}</span></p>)}</div>
            <div><p className="label">Newest listings</p>{data.activity.newListings.map((p) => <p key={p.id} className="flex justify-between py-0.5"><Link to={`/product/${p.id}`} className="truncate hover:text-brand-700">{p.title}</Link><span className="shrink-0 pl-2 text-xs text-slate-400">{timeAgo(p.createdAt)}</span></p>)}</div>
            <div><p className="label">Latest exchanges</p>{data.activity.recentTransactions.length ? data.activity.recentTransactions.map((t) => <p key={t.id} className="flex items-center justify-between py-0.5"><span className="truncate">{t.product?.title} · {inr(t.finalPricePaise)}</span><StatusBadge status={t.status} /></p>) : <p className="text-xs text-slate-400">None yet</p>}</div>
          </div>
        </div>
      </div>
    </div>
  )
}

function UsersTab() {
  const toast = useToast()
  const [q, setQ] = useState('')
  const [term, setTerm] = useState('')
  const [page, setPage] = useState(1)
  const { data, loading, error, reload } = useFetch('/admin/users', { params: { q: term, page } })
  const setStatus = async (u, status) => {
    if (!confirm(`${status === 'suspended' ? 'Suspend' : 'Reactivate'} ${u.name}?`)) return
    try { await api.patch(`/admin/users/${u.id}/status`, { status }); toast.success(`Account ${status}`); reload() } catch (e) { toast.error(errMsg(e)) }
  }
  return (
    <div>
      <form className="mb-4 flex gap-2" onSubmit={(e) => { e.preventDefault(); setPage(1); setTerm(q) }}>
        <div className="relative flex-1"><Search className="absolute left-3.5 top-3 h-4 w-4 text-slate-400" /><input className="input pl-10" placeholder="Search by name or email" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <button className="btn-primary">Search</button>
      </form>
      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading ? <Spinner /> : (
        <div className="card overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-100 text-left text-xs uppercase text-slate-400"><th className="p-3">User</th><th>College</th><th>Role</th><th>Verified</th><th>Status</th><th>Joined</th><th /></tr></thead>
            <tbody>{data.items.map((u) => (
              <tr key={u.id} className="border-b border-slate-50">
                <td className="p-3"><div className="flex items-center gap-2"><Avatar user={u} size="h-8 w-8" /><div><Link to={`/profile/${u.id}`} className="font-semibold hover:text-brand-700">{u.name}</Link><p className="text-xs text-slate-400">{u.email}</p></div></div></td>
                <td className="text-xs">{u.department}<br /><span className="text-slate-400">{u.college}</span></td>
                <td className="capitalize">{u.role}</td>
                <td>{u.verified ? <CheckCircle2 className="h-4 w-4 text-mint-500" /> : <span className="text-xs text-slate-400">No</span>}</td>
                <td><StatusBadge status={u.accountStatus} /></td>
                <td className="text-xs text-slate-500">{timeAgo(u.createdAt)}</td>
                <td className="pr-3 text-right">{u.role !== 'admin' && (u.accountStatus === 'active'
                  ? <button className="btn-danger px-3 py-1" onClick={() => setStatus(u, 'suspended')}><Ban className="h-3.5 w-3.5" />Suspend</button>
                  : <button className="btn-mint px-3 py-1" onClick={() => setStatus(u, 'active')}><RotateCcw className="h-3.5 w-3.5" />Reactivate</button>)}</td>
              </tr>
            ))}</tbody>
          </table>
          <div className="flex items-center justify-between p-3 text-xs text-slate-500">
            <span>{data.total} users</span>
            <div className="flex gap-2"><button className="btn-ghost px-3 py-1" disabled={page <= 1} onClick={() => setPage(page - 1)}>Prev</button><button className="btn-ghost px-3 py-1" disabled={page * data.pageSize >= data.total} onClick={() => setPage(page + 1)}>Next</button></div>
          </div>
        </div>
      )}
    </div>
  )
}

function ListingsTab() {
  const toast = useToast()
  const [q, setQ] = useState('')
  const [term, setTerm] = useState('')
  const [status, setStatus] = useState('')
  const [page, setPage] = useState(1)
  const { data, loading, error, reload } = useFetch('/admin/listings', { params: { q: term, status, page } })
  const set = async (p, s) => {
    try { await api.patch(`/admin/listings/${p.id}/status`, { status: s }); toast.success(s === 'removed' ? 'Listing removed' : 'Listing restored'); reload() } catch (e) { toast.error(errMsg(e)) }
  }
  return (
    <div>
      <form className="mb-4 flex flex-wrap gap-2" onSubmit={(e) => { e.preventDefault(); setPage(1); setTerm(q) }}>
        <div className="relative min-w-52 flex-1"><Search className="absolute left-3.5 top-3 h-4 w-4 text-slate-400" /><input className="input pl-10" placeholder="Search listings" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <select className="input w-auto" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1) }}><option value="">All statuses</option>{['active', 'reserved', 'sold', 'removed'].map((s) => <option key={s}>{s}</option>)}</select>
        <button className="btn-primary">Search</button>
      </form>
      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading ? <Spinner /> : (
        <div className="card overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-100 text-left text-xs uppercase text-slate-400"><th className="p-3">Listing</th><th>Seller</th><th>Price</th><th>Status</th><th>Posted</th><th /></tr></thead>
            <tbody>{data.items.map((p) => (
              <tr key={p.id} className="border-b border-slate-50">
                <td className="p-3"><Link to={`/product/${p.id}`} className="font-semibold hover:text-brand-700">{p.title}</Link><p className="text-xs text-slate-400">{p.category?.name}</p></td>
                <td className="text-xs">{p.seller?.name}</td><td>{inr(p.pricePaise)}</td><td><StatusBadge status={p.status} /></td><td className="text-xs text-slate-500">{timeAgo(p.createdAt)}</td>
                <td className="pr-3 text-right">{p.status === 'removed' ? <button className="btn-mint px-3 py-1" onClick={() => set(p, 'active')}>Restore</button> : p.status !== 'sold' && <button className="btn-danger px-3 py-1" onClick={() => confirm(`Remove "${p.title}"?`) && set(p, 'removed')}><Trash2 className="h-3.5 w-3.5" />Remove</button>}</td>
              </tr>
            ))}</tbody>
          </table>
          <div className="flex items-center justify-between p-3 text-xs text-slate-500">
            <span>{data.total} listings</span>
            <div className="flex gap-2"><button className="btn-ghost px-3 py-1" disabled={page <= 1} onClick={() => setPage(page - 1)}>Prev</button><button className="btn-ghost px-3 py-1" disabled={page * data.pageSize >= data.total} onClick={() => setPage(page + 1)}>Next</button></div>
          </div>
        </div>
      )}
    </div>
  )
}

function ReportsTab() {
  const toast = useToast()
  const [status, setStatus] = useState('pending')
  const { data, loading, error, reload } = useFetch('/admin/reports', { params: { status } })
  const resolve = async (r, s, removeListing) => {
    try { await api.patch(`/admin/reports/${r.id}`, { status: s, removeListing }); toast.success(`Report ${s}`); reload() } catch (e) { toast.error(errMsg(e)) }
  }
  return (
    <div>
      <div className="mb-4 flex gap-1 rounded-xl bg-white p-1 shadow-card sm:w-fit">
        {['pending', 'resolved', 'dismissed'].map((s) => <button key={s} onClick={() => setStatus(s)} className={`rounded-lg px-4 py-1.5 text-sm font-semibold capitalize ${status === s ? 'bg-brand-700 text-white' : 'text-slate-500'}`}>{s}</button>)}
      </div>
      {error && <ErrorBox message={error} onRetry={reload} />}
      {loading ? <Spinner /> : !data?.items?.length ? <Empty title={`No ${status} reports`} /> : (
        <div className="space-y-3">{data.items.map((r) => (
          <div key={r.id} className="card p-4">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <p className="font-semibold"><Flag className="mr-1 inline h-4 w-4 text-red-500" />{r.reason}</p>
                <p className="mt-0.5 text-sm text-slate-600">{r.description || 'No details provided.'}</p>
                <p className="mt-2 text-xs text-slate-500">Listing: <Link to={`/product/${r.productId}`} className="font-medium text-brand-600">{r.product?.title}</Link> ({r.product?.status}) · seller {r.product?.seller?.name} · reported by {r.reporter?.name} · {fmtTime(r.createdAt)}</p>
              </div>
              <StatusBadge status={r.status} />
            </div>
            {r.status === 'pending' && (
              <div className="mt-3 flex flex-wrap gap-2 border-t border-slate-100 pt-3">
                <button className="btn-danger px-3 py-1.5" onClick={() => resolve(r, 'resolved', true)}><Trash2 className="h-4 w-4" />Remove listing & resolve</button>
                <button className="btn-ghost px-3 py-1.5" onClick={() => resolve(r, 'resolved', false)}>Resolve (keep listing)</button>
                <button className="btn-ghost px-3 py-1.5" onClick={() => resolve(r, 'dismissed', false)}>Dismiss</button>
              </div>
            )}
          </div>
        ))}</div>
      )}
    </div>
  )
}

export default function AdminDashboard() {
  const [tab, setTab] = useState('overview')
  const tabs = [['overview', 'Overview'], ['users', 'Users'], ['listings', 'Listings'], ['reports', 'Reports']]
  return (
    <div>
      <PageHeader title="Admin dashboard" subtitle="Moderate the marketplace and monitor activity." />
      <div className="mb-6 flex gap-1 overflow-x-auto rounded-xl bg-white p-1 shadow-card sm:w-fit">
        {tabs.map(([k, l]) => <button key={k} onClick={() => setTab(k)} className={`rounded-lg px-5 py-1.5 text-sm font-semibold transition ${tab === k ? 'bg-brand-700 text-white' : 'text-slate-500 hover:text-brand-700'}`}>{l}</button>)}
      </div>
      {tab === 'overview' && <Overview />}
      {tab === 'users' && <UsersTab />}
      {tab === 'listings' && <ListingsTab />}
      {tab === 'reports' && <ReportsTab />}
    </div>
  )
}
