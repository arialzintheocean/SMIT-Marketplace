import { useEffect, useRef, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { Loader2, Send } from 'lucide-react'
import api, { errMsg } from '../services/api'
import useFetch from '../hooks/useFetch'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { Avatar, Empty, PageHeader, Spinner } from '../components/ui'
import { ProductImage } from '../components/ProductCard'
import { fmtTime, inr, timeAgo } from '../utils/format'

function Thread({ id, onSent }) {
  const { user } = useAuth()
  const toast = useToast()
  const { data, loading, reload } = useFetch(`/conversations/${id}/messages`, { interval: 5000 })
  const [text, setText] = useState('')
  const [busy, setBusy] = useState(false)
  const endRef = useRef(null)
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [data?.messages?.length])

  const send = async (e) => {
    e.preventDefault()
    if (!text.trim()) return
    setBusy(true)
    try { await api.post(`/conversations/${id}/messages`, { message: text }); setText(''); await reload(); onSent() }
    catch (err) { toast.error(errMsg(err)) } finally { setBusy(false) }
  }

  if (loading && !data) return <Spinner />
  const cv = data.conversation
  const other = cv.buyerId === user.id ? cv.seller : cv.buyer
  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-3 border-b border-slate-100 p-4">
        <Link to={`/product/${cv.productId}`} className="h-12 w-14 shrink-0 overflow-hidden rounded-lg"><ProductImage product={cv.product} className="h-full w-full" /></Link>
        <div className="min-w-0 flex-1">
          <Link to={`/profile/${other.id}`} className="font-semibold hover:text-brand-700">{other.name}</Link>
          <Link to={`/product/${cv.productId}`} className="block truncate text-xs text-slate-500 hover:underline">{cv.product.title} · {inr(cv.product.pricePaise)}</Link>
        </div>
      </div>
      <div className="flex-1 space-y-3 overflow-y-auto bg-slate-50 p-4">
        {!data.messages.length && <p className="py-10 text-center text-sm text-slate-400">No messages yet — say hello!</p>}
        {data.messages.map((m) => {
          const mine = m.senderId === user.id
          return (
            <div key={m.id} className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[75%] rounded-2xl px-4 py-2 text-sm shadow-sm ${mine ? 'rounded-br-sm bg-brand-700 text-white' : 'rounded-bl-sm bg-white text-slate-800'}`}>
                <p className="whitespace-pre-wrap break-words">{m.message}</p>
                <p className={`mt-1 text-[10px] ${mine ? 'text-brand-200' : 'text-slate-400'}`}>{fmtTime(m.createdAt)}</p>
              </div>
            </div>
          )
        })}
        <div ref={endRef} />
      </div>
      <form onSubmit={send} className="flex gap-2 border-t border-slate-100 p-3">
        <input className="input" placeholder="Type a message…" maxLength={2000} value={text} onChange={(e) => setText(e.target.value)} />
        <button className="btn-primary" disabled={busy || !text.trim()}>{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}</button>
      </form>
    </div>
  )
}

export default function Messages() {
  const [sp, setSp] = useSearchParams()
  const [role, setRole] = useState('all')
  const { data, loading, reload } = useFetch('/conversations', { params: role === 'all' ? {} : { role }, interval: 8000 })
  const active = sp.get('c')

  return (
    <div>
      <PageHeader title="Messages" subtitle={data?.totalUnread ? `${data.totalUnread} unread` : 'Your conversations about listings'} />
      <div className="card grid h-[70vh] overflow-hidden md:grid-cols-[320px_1fr]">
        <div className={`flex flex-col border-r border-slate-100 ${active ? 'hidden md:flex' : 'flex'}`}>
          <div className="flex gap-1 border-b border-slate-100 p-2">
            {[['all', 'All'], ['buyer', 'Buying'], ['seller', 'Selling']].map(([k, l]) => (
              <button key={k} onClick={() => setRole(k)} className={`flex-1 rounded-lg py-1.5 text-xs font-semibold ${role === k ? 'bg-brand-700 text-white' : 'text-slate-500 hover:bg-slate-50'}`}>{l}</button>
            ))}
          </div>
          <div className="flex-1 overflow-y-auto">
            {loading && !data ? <Spinner /> : !data?.items?.length ? <div className="p-4"><Empty title="No conversations" hint="Message a seller from any listing." /></div> : data.items.map((c) => {
              const other = c.role === 'buyer' ? c.seller : c.buyer
              return (
                <button key={c.id} onClick={() => setSp({ c: c.id })} className={`flex w-full items-center gap-3 border-b border-slate-50 p-3 text-left transition hover:bg-slate-50 ${String(c.id) === active ? 'bg-brand-50' : ''}`}>
                  <Avatar user={other} size="h-11 w-11" />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between"><span className="truncate text-sm font-semibold">{other.name}</span>{c.last && <span className="text-[10px] text-slate-400">{timeAgo(c.last.createdAt)}</span>}</div>
                    <p className="truncate text-xs text-slate-500">{c.product.title}</p>
                    <p className={`truncate text-xs ${c.unread ? 'font-semibold text-slate-800' : 'text-slate-400'}`}>{c.last?.message || 'No messages yet'}</p>
                  </div>
                  {c.unread > 0 && <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-mint-500 px-1.5 text-[11px] font-bold text-white">{c.unread}</span>}
                </button>
              )
            })}
          </div>
        </div>
        <div className={`${active ? 'block' : 'hidden md:flex md:items-center md:justify-center'} min-h-0`}>
          {active ? (
            <div className="flex h-full flex-col">
              <button onClick={() => setSp({})} className="border-b border-slate-100 px-4 py-2 text-left text-xs font-semibold text-brand-600 md:hidden">← Back to inbox</button>
              <div className="min-h-0 flex-1"><Thread key={active} id={active} onSent={reload} /></div>
            </div>
          ) : <p className="text-sm text-slate-400">Select a conversation</p>}
        </div>
      </div>
    </div>
  )
}
