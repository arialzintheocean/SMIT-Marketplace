import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { Flag, Handshake, Heart, MapPin, MessageCircle, Pencil, ShoppingBag, Eye } from 'lucide-react'
import api, { errMsg } from '../services/api'
import useFetch from '../hooks/useFetch'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { Avatar, ErrorBox, Modal, Spinner, Stars, StatusBadge } from '../components/ui'
import { inr, pushRecent, timeAgo } from '../utils/format'
import { ProductImage } from '../components/ProductCard'

export default function ProductDetail() {
  const { id } = useParams()
  const { user } = useAuth()
  const toast = useToast()
  const nav = useNavigate()
  const { data, loading, error, reload } = useFetch(`/products/${id}`)
  const [img, setImg] = useState(0)
  const [modal, setModal] = useState(null) // 'offer' | 'chat' | 'report' | 'buy'
  const [form, setForm] = useState({ price: '', message: '', reason: 'Inappropriate item' })
  const [busy, setBusy] = useState(false)
  const [saved, setSaved] = useState(false)

  useEffect(() => { pushRecent(Number(id)); setImg(0) }, [id])
  useEffect(() => { if (data) setSaved(!!data.wishlisted) }, [data])

  if (loading) return <Spinner />
  if (error) return <ErrorBox message={error} onRetry={reload} />
  const p = data.product
  const isOwner = data.isOwner
  const available = p.status === 'active'
  const needLogin = () => { toast.error('Please log in first'); nav('/login', { state: { from: `/product/${id}` } }) }
  const open = (m) => { if (!user) return needLogin(); setForm({ ...form, price: '', message: '' }); setModal(m) }

  const run = async (fn, okMsg, after) => {
    setBusy(true)
    try { await fn(); toast.success(okMsg); setModal(null); after?.() } catch (e) { toast.error(errMsg(e)) } finally { setBusy(false) }
  }

  const toggleSave = async () => {
    if (!user) return needLogin()
    try {
      if (saved) await api.delete(`/wishlist/${p.id}`); else await api.post(`/wishlist/${p.id}`)
      setSaved(!saved)
    } catch (e) { toast.error(errMsg(e)) }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[1.2fr_1fr]">
      <div>
        <div className="card overflow-hidden"><ProductImage product={{ ...p, images: p.images?.slice(img) }} className="aspect-[4/3] w-full" /></div>
        {p.images?.length > 1 && (
          <div className="mt-3 flex gap-2 overflow-x-auto">
            {p.images.map((im, i) => (
              <button key={im.id} onClick={() => setImg(i)} className={`h-16 w-20 shrink-0 overflow-hidden rounded-xl border-2 transition ${i === img ? 'border-brand-600' : 'border-transparent opacity-70 hover:opacity-100'}`}>
                <img src={im.imagePath} alt="" className="h-full w-full object-cover" />
              </button>
            ))}
          </div>
        )}
        <div className="card mt-6 p-6">
          <h2 className="mb-2 font-bold text-brand-900">Description</h2>
          <p className="whitespace-pre-wrap text-sm leading-relaxed text-slate-600">{p.description || 'No description provided.'}</p>
        </div>
      </div>

      <div className="space-y-5">
        <div className="card p-6">
          <div className="flex items-start justify-between gap-3">
            <h1 className="text-2xl font-extrabold text-brand-900">{p.title}</h1>
            <StatusBadge status={p.status} />
          </div>
          <div className="mt-3 flex items-center gap-3">
            <span className="text-3xl font-extrabold text-brand-700">{inr(p.pricePaise)}</span>
            <span className={`badge ${p.negotiable ? 'bg-mint-100 text-mint-700' : 'bg-slate-100 text-slate-600'}`}>{p.negotiable ? 'Negotiable' : 'Fixed price'}</span>
          </div>
          <dl className="mt-5 grid grid-cols-2 gap-3 text-sm">
            <div><dt className="label">Condition</dt><dd className="font-medium">{p.condition}</dd></div>
            <div><dt className="label">Category</dt><dd className="font-medium">{p.category?.name}</dd></div>
            <div><dt className="label">Pickup</dt><dd className="flex items-center gap-1 font-medium"><MapPin className="h-3.5 w-3.5 text-mint-600" />{p.pickupLocation}</dd></div>
            <div><dt className="label">Posted</dt><dd className="font-medium">{timeAgo(p.createdAt)} · <Eye className="inline h-3.5 w-3.5" /> {p.views}</dd></div>
          </dl>

          {isOwner ? (
            <div className="mt-6 flex gap-2">
              <Link to={`/edit/${p.id}`} className="btn-primary flex-1"><Pencil className="h-4 w-4" />Edit listing</Link>
              <Link to="/my-listings" className="btn-ghost flex-1">Manage</Link>
            </div>
          ) : (
            <div className="mt-6 space-y-2">
              {!available && <p className="rounded-xl bg-amber-50 px-3 py-2 text-sm text-amber-700">This item is {p.status} and not accepting new offers or requests.</p>}
              <button className="btn-primary w-full" disabled={!available} onClick={() => open('buy')}><ShoppingBag className="h-4 w-4" />Request to buy at {inr(p.pricePaise)}</button>
              <div className="grid grid-cols-2 gap-2">
                {p.negotiable && <button className="btn-mint" disabled={!available} onClick={() => open('offer')}><Handshake className="h-4 w-4" />Make offer</button>}
                <button className={`btn-ghost ${p.negotiable ? '' : 'col-span-1'}`} onClick={() => open('chat')}><MessageCircle className="h-4 w-4" />Message</button>
                <button className="btn-ghost" onClick={toggleSave}><Heart className={`h-4 w-4 ${saved ? 'fill-red-500 text-red-500' : ''}`} />{saved ? 'Saved' : 'Save'}</button>
              </div>
            </div>
          )}
        </div>

        <div className="card p-5">
          <p className="label">Seller</p>
          <Link to={`/profile/${p.seller?.id}`} className="flex items-center gap-3 rounded-xl p-1 transition hover:bg-slate-50">
            <Avatar user={p.seller} size="h-12 w-12" />
            <div>
              <p className="font-semibold">{p.seller?.name}</p>
              <p className="text-xs text-slate-500">{p.seller?.department} · Year {p.seller?.year}</p>
              <div className="mt-0.5 flex items-center gap-1 text-xs text-slate-500"><Stars value={data.sellerRating} size="h-3.5 w-3.5" />{data.sellerReviews ? `${data.sellerRating.toFixed(1)} (${data.sellerReviews})` : 'No reviews yet'}</div>
            </div>
          </Link>
          {!isOwner && <button onClick={() => open('report')} className="mt-4 flex items-center gap-1 text-xs font-medium text-slate-400 hover:text-red-500"><Flag className="h-3 w-3" />Report this listing</button>}
        </div>
      </div>

      <Modal open={modal === 'offer'} onClose={() => setModal(null)} title="Make an offer">
        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); run(() => api.post('/offers', { productId: p.id, price: Number(form.price), message: form.message }), 'Offer sent to the seller', () => nav('/offers')) }}>
          <p className="text-sm text-slate-500">Listed at <b>{inr(p.pricePaise)}</b>. Your offer must be lower.</p>
          <div><label className="label">Your offer (₹)</label><input className="input" type="number" min="1" max={p.pricePaise / 100 - 1} required value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} /></div>
          <div><label className="label">Message (optional)</label><textarea className="input" rows={3} maxLength={500} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} /></div>
          <button className="btn-primary w-full" disabled={busy}>Send offer</button>
        </form>
      </Modal>

      <Modal open={modal === 'buy'} onClose={() => setModal(null)} title="Send purchase request">
        <p className="mb-4 text-sm text-slate-500">The seller will be notified. If they accept, the item is reserved for you and you can arrange campus pickup at <b>{p.pickupLocation}</b>.</p>
        <button className="btn-primary w-full" disabled={busy} onClick={() => run(() => api.post('/transactions', { productId: p.id }), 'Request sent', () => nav('/transactions'))}>Confirm request for {inr(p.pricePaise)}</button>
      </Modal>

      <Modal open={modal === 'chat'} onClose={() => setModal(null)} title={`Message ${p.seller?.name?.split(' ')[0]}`}>
        <form className="space-y-4" onSubmit={async (e) => {
          e.preventDefault()
          setBusy(true)
          try { const { data: cv } = await api.post('/conversations', { productId: p.id, message: form.message }); nav(`/messages?c=${cv.id}`) }
          catch (err) { toast.error(errMsg(err)) } finally { setBusy(false) }
        }}>
          <textarea className="input" rows={4} required maxLength={2000} placeholder="Hi! Is this still available?" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
          <button className="btn-primary w-full" disabled={busy}>Send message</button>
        </form>
      </Modal>

      <Modal open={modal === 'report'} onClose={() => setModal(null)} title="Report listing">
        <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); run(() => api.post('/reports', { productId: p.id, reason: form.reason, description: form.message }), 'Report submitted') }}>
          <select className="input" value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })}>
            {['Inappropriate item', 'Scam or fake listing', 'Prohibited item', 'Wrong category', 'Other'].map((r) => <option key={r}>{r}</option>)}
          </select>
          <textarea className="input" rows={3} maxLength={1000} placeholder="Details (optional)" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
          <button className="btn-danger w-full" disabled={busy}>Submit report</button>
        </form>
      </Modal>
    </div>
  )
}
