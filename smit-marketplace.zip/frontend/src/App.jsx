import { Route, Routes } from 'react-router-dom'
import MainLayout from './layouts/MainLayout'
import ProtectedRoute from './components/ProtectedRoute'
import Landing from './pages/Landing'
import Register from './pages/Register'
import Login from './pages/Login'
import Marketplace from './pages/Marketplace'
import ProductDetail from './pages/ProductDetail'
import ListingForm from './pages/ListingForm'
import Wishlist from './pages/Wishlist'
import Dashboard from './pages/Dashboard'
import MyListings from './pages/MyListings'
import Offers from './pages/Offers'
import Messages from './pages/Messages'
import Transactions from './pages/Transactions'
import Profile from './pages/Profile'
import AdminDashboard from './pages/AdminDashboard'

const P = ({ children, role }) => <ProtectedRoute role={role}>{children}</ProtectedRoute>

export default function App() {
  return (
    <Routes>
      <Route element={<MainLayout />}>
        <Route path="/" element={<Landing />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/marketplace" element={<Marketplace />} />
        <Route path="/product/:id" element={<ProductDetail />} />
        <Route path="/create" element={<P><ListingForm /></P>} />
        <Route path="/edit/:id" element={<P><ListingForm /></P>} />
        <Route path="/wishlist" element={<P><Wishlist /></P>} />
        <Route path="/dashboard" element={<P><Dashboard /></P>} />
        <Route path="/my-listings" element={<P><MyListings /></P>} />
        <Route path="/offers" element={<P><Offers /></P>} />
        <Route path="/messages" element={<P><Messages /></P>} />
        <Route path="/transactions" element={<P><Transactions /></P>} />
        <Route path="/profile/:id" element={<P><Profile /></P>} />
        <Route path="/admin" element={<P role="admin"><AdminDashboard /></P>} />
        <Route path="*" element={<div className="py-24 text-center text-slate-500">Page not found</div>} />
      </Route>
    </Routes>
  )
}
