package services

import (
	"smitmarket/models"

	"gorm.io/gorm"
)

// Notify creates an in-app notification. Pass a tx to keep it atomic with related writes.
func Notify(db *gorm.DB, userID uint, title, msg, link string) {
	db.Create(&models.Notification{UserID: userID, Title: title, Message: msg, Link: link})
}
