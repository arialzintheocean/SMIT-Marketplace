package routes

import (
	"smitmarket/config"
	"smitmarket/handlers"
	"smitmarket/middleware"
	"smitmarket/models"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

func Setup(db *gorm.DB, cfg *config.Config) *gin.Engine {
	if !cfg.IsDev() {
		gin.SetMode(gin.ReleaseMode)
	}
	r := gin.Default()
	r.MaxMultipartMemory = 32 << 20
	r.Use(cors.New(cors.Config{
		AllowOrigins:     []string{cfg.FrontendOrigin},
		AllowMethods:     []string{"GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"},
		AllowHeaders:     []string{"Authorization", "Content-Type"},
		AllowCredentials: false,
	}))
	r.Static("/uploads", cfg.UploadDir)

	h := handlers.New(db, cfg)
	auth := middleware.Auth(db, cfg.JWTSecret)
	opt := middleware.OptionalAuth(db, cfg.JWTSecret)
	verified := middleware.RequireVerified()
	admin := middleware.RequireRole(models.RoleAdmin)

	api := r.Group("/api")
	api.GET("/health", func(c *gin.Context) { c.JSON(200, gin.H{"status": "ok"}) })
	api.GET("/categories", h.Categories)

	a := api.Group("/auth")
	a.POST("/register", h.Register)
	a.POST("/verify-email", h.VerifyEmail)
	a.POST("/resend-otp", h.ResendOTP)
	a.POST("/login", h.Login)
	a.GET("/me", auth, h.Me)
	a.PUT("/profile", auth, h.UpdateProfile)

	p := api.Group("/products")
	p.GET("", h.ListProducts)
	p.GET("/batch", h.ProductsByIDs)
	p.GET("/:id", opt, h.GetProduct)
	p.POST("", auth, verified, h.CreateProduct)
	p.PUT("/:id", auth, verified, h.UpdateProduct)
	p.DELETE("/:id", auth, verified, h.DeleteProduct)
	p.PATCH("/:id/status", auth, verified, h.SetProductStatus)
	p.GET("/:id/interested", auth, h.Interested)
	api.GET("/my/products", auth, h.MyProducts)

	w := api.Group("/wishlist", auth)
	w.GET("", h.GetWishlist)
	w.POST("/:productId", h.AddWishlist)
	w.DELETE("/:productId", h.RemoveWishlist)

	o := api.Group("/offers", auth)
	o.POST("", verified, h.CreateOffer)
	o.GET("/received", h.OffersReceived)
	o.GET("/sent", h.OffersSent)
	o.PATCH("/:id/respond", verified, h.RespondOffer)
	o.PATCH("/:id/withdraw", verified, h.WithdrawOffer)

	cv := api.Group("/conversations", auth)
	cv.GET("", h.ListConversations)
	cv.POST("", verified, h.StartConversation)
	cv.GET("/:id/messages", h.GetMessages)
	cv.POST("/:id/messages", verified, h.SendMessage)

	t := api.Group("/transactions", auth)
	t.POST("", verified, h.CreateTransaction)
	t.GET("", h.ListTransactions)
	t.PATCH("/:id/status", verified, h.UpdateTransactionStatus)

	api.POST("/reviews", auth, verified, h.CreateReview)
	api.GET("/users/:id/reviews", auth, h.UserReviews)
	api.POST("/reports", auth, verified, h.CreateReport)
	api.GET("/dashboard", auth, h.Dashboard)

	n := api.Group("/notifications", auth)
	n.GET("", h.ListNotifications)
	n.PATCH("/read-all", h.MarkAllRead)
	n.PATCH("/:id/read", h.MarkNotificationRead)

	ad := api.Group("/admin", auth, admin)
	ad.GET("/dashboard", h.AdminDashboard)
	ad.GET("/users", h.AdminUsers)
	ad.PATCH("/users/:id/status", h.AdminSetUserStatus)
	ad.GET("/listings", h.AdminListings)
	ad.PATCH("/listings/:id/status", h.AdminSetListingStatus)
	ad.GET("/reports", h.AdminReports)
	ad.PATCH("/reports/:id", h.AdminResolveReport)

	return r
}
