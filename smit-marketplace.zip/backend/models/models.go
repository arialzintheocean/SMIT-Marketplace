package models

import "time"

const (
	RoleStudent = "student"
	RoleAdmin   = "admin"

	AccountActive    = "active"
	AccountSuspended = "suspended"

	ProductPending  = "pending"
	ProductActive   = "active"
	ProductReserved = "reserved"
	ProductSold     = "sold"
	ProductRemoved  = "removed"

	OfferPending   = "pending"
	OfferAccepted  = "accepted"
	OfferRejected  = "rejected"
	OfferCountered = "countered"
	OfferWithdrawn = "withdrawn"

	TxRequested = "requested"
	TxAccepted  = "accepted"
	TxRejected  = "rejected"
	TxReserved  = "reserved"
	TxCompleted = "completed"
	TxCancelled = "cancelled"
)

var Conditions = []string{"Brand New", "Like New", "Good", "Fair", "Used"}

type User struct {
	ID                 uint      `gorm:"primaryKey" json:"id"`
	Name               string    `gorm:"size:120;not null" json:"name"`
	Email              string    `gorm:"size:190;uniqueIndex;not null" json:"email"`
	PasswordHash       string    `gorm:"not null" json:"-"`
	College            string    `gorm:"size:160" json:"college"`
	Department         string    `gorm:"size:160" json:"department"`
	Year               int       `json:"year"`
	ProfileImage       string    `json:"profileImage"`
	Role               string    `gorm:"size:20;default:student;index" json:"role"`
	VerificationStatus bool      `gorm:"default:false" json:"verified"`
	AccountStatus      string    `gorm:"size:20;default:active;index" json:"accountStatus"`
	IsDemo             bool      `gorm:"default:false" json:"isDemo"`
	OTPHash            string    `json:"-"`
	OTPExpiresAt       time.Time `json:"-"`
	CreatedAt          time.Time `json:"createdAt"`
}

type Category struct {
	ID   uint   `gorm:"primaryKey" json:"id"`
	Name string `gorm:"size:100;uniqueIndex;not null" json:"name"`
}

type Product struct {
	ID             uint           `gorm:"primaryKey" json:"id"`
	SellerID       uint           `gorm:"index;not null" json:"sellerId"`
	Seller         *User          `gorm:"foreignKey:SellerID" json:"seller,omitempty"`
	Title          string         `gorm:"size:200;index;not null" json:"title"`
	Description    string         `gorm:"type:text" json:"description"`
	PricePaise     int64          `gorm:"not null" json:"pricePaise"`
	CategoryID     uint           `gorm:"index;not null" json:"categoryId"`
	Category       *Category      `gorm:"foreignKey:CategoryID" json:"category,omitempty"`
	Condition      string         `gorm:"size:30;index" json:"condition"`
	Negotiable     bool           `json:"negotiable"`
	PickupLocation string         `gorm:"size:200" json:"pickupLocation"`
	Status         string         `gorm:"size:20;index;default:active" json:"status"`
	Views          int            `json:"views"`
	Images         []ProductImage `gorm:"foreignKey:ProductID;constraint:OnDelete:CASCADE" json:"images"`
	CreatedAt      time.Time      `json:"createdAt"`
	UpdatedAt      time.Time      `json:"updatedAt"`
}

type ProductImage struct {
	ID        uint   `gorm:"primaryKey" json:"id"`
	ProductID uint   `gorm:"index;not null" json:"productId"`
	ImagePath string `json:"imagePath"`
}

type Wishlist struct {
	ID        uint      `gorm:"primaryKey" json:"id"`
	UserID    uint      `gorm:"uniqueIndex:uq_wish;not null" json:"userId"`
	ProductID uint      `gorm:"uniqueIndex:uq_wish;not null" json:"productId"`
	Product   *Product  `gorm:"foreignKey:ProductID" json:"product,omitempty"`
	CreatedAt time.Time `json:"createdAt"`
}

type Offer struct {
	ID                uint      `gorm:"primaryKey" json:"id"`
	ProductID         uint      `gorm:"index;not null" json:"productId"`
	Product           *Product  `gorm:"foreignKey:ProductID" json:"product,omitempty"`
	BuyerID           uint      `gorm:"index;not null" json:"buyerId"`
	Buyer             *User     `gorm:"foreignKey:BuyerID" json:"buyer,omitempty"`
	ParentOfferID     *uint     `gorm:"index" json:"parentOfferId"`
	FromSeller        bool      `json:"fromSeller"` // true when this row is a seller counter-offer
	OfferedPricePaise int64     `gorm:"not null" json:"offeredPricePaise"`
	Message           string    `gorm:"size:500" json:"message"`
	Status            string    `gorm:"size:20;index;default:pending" json:"status"`
	CreatedAt         time.Time `json:"createdAt"`
	UpdatedAt         time.Time `json:"updatedAt"`
}

type Conversation struct {
	ID        uint      `gorm:"primaryKey" json:"id"`
	ProductID uint      `gorm:"uniqueIndex:uq_conv;not null" json:"productId"`
	Product   *Product  `gorm:"foreignKey:ProductID" json:"product,omitempty"`
	BuyerID   uint      `gorm:"uniqueIndex:uq_conv;index;not null" json:"buyerId"`
	Buyer     *User     `gorm:"foreignKey:BuyerID" json:"buyer,omitempty"`
	SellerID  uint      `gorm:"index;not null" json:"sellerId"`
	Seller    *User     `gorm:"foreignKey:SellerID" json:"seller,omitempty"`
	CreatedAt time.Time `json:"createdAt"`
}

type Message struct {
	ID             uint      `gorm:"primaryKey" json:"id"`
	ConversationID uint      `gorm:"index;not null" json:"conversationId"`
	SenderID       uint      `gorm:"index;not null" json:"senderId"`
	Message        string    `gorm:"type:text;not null" json:"message"`
	IsRead         bool      `gorm:"default:false" json:"isRead"`
	CreatedAt      time.Time `json:"createdAt"`
}

type Transaction struct {
	ID              uint       `gorm:"primaryKey" json:"id"`
	ProductID       uint       `gorm:"index;not null" json:"productId"`
	Product         *Product   `gorm:"foreignKey:ProductID" json:"product,omitempty"`
	BuyerID         uint       `gorm:"index;not null" json:"buyerId"`
	Buyer           *User      `gorm:"foreignKey:BuyerID" json:"buyer,omitempty"`
	SellerID        uint       `gorm:"index;not null" json:"sellerId"`
	Seller          *User      `gorm:"foreignKey:SellerID" json:"seller,omitempty"`
	FinalPricePaise int64      `json:"finalPricePaise"`
	Status          string     `gorm:"size:20;index;default:requested" json:"status"`
	CreatedAt       time.Time  `json:"createdAt"`
	CompletedAt     *time.Time `json:"completedAt"`
}

type Review struct {
	ID            uint      `gorm:"primaryKey" json:"id"`
	TransactionID uint      `gorm:"uniqueIndex:uq_review;not null" json:"transactionId"`
	ReviewerID    uint      `gorm:"uniqueIndex:uq_review;not null" json:"reviewerId"`
	Reviewer      *User     `gorm:"foreignKey:ReviewerID" json:"reviewer,omitempty"`
	RevieweeID    uint      `gorm:"index;not null" json:"revieweeId"`
	Rating        int       `gorm:"not null" json:"rating"`
	Comment       string    `gorm:"size:500" json:"comment"`
	CreatedAt     time.Time `json:"createdAt"`
}

type Notification struct {
	ID        uint      `gorm:"primaryKey" json:"id"`
	UserID    uint      `gorm:"index;not null" json:"userId"`
	Title     string    `gorm:"size:160" json:"title"`
	Message   string    `gorm:"size:500" json:"message"`
	Link      string    `json:"link"`
	IsRead    bool      `gorm:"default:false" json:"isRead"`
	CreatedAt time.Time `json:"createdAt"`
}

type Report struct {
	ID          uint      `gorm:"primaryKey" json:"id"`
	ReporterID  uint      `gorm:"index;not null" json:"reporterId"`
	Reporter    *User     `gorm:"foreignKey:ReporterID" json:"reporter,omitempty"`
	ProductID   uint      `gorm:"index;not null" json:"productId"`
	Product     *Product  `gorm:"foreignKey:ProductID" json:"product,omitempty"`
	Reason      string    `gorm:"size:100" json:"reason"`
	Description string    `gorm:"size:1000" json:"description"`
	Status      string    `gorm:"size:20;index;default:pending" json:"status"`
	CreatedAt   time.Time `json:"createdAt"`
}

func All() []interface{} {
	return []interface{}{&User{}, &Category{}, &Product{}, &ProductImage{}, &Wishlist{}, &Offer{},
		&Conversation{}, &Message{}, &Transaction{}, &Review{}, &Notification{}, &Report{}}
}

var CategoryNames = []string{
	"Books and Academic Materials", "Electronics and Gadgets", "Hostel and Room Essentials",
	"Clothing and Accessories", "Cycles and Sports Equipment", "Furniture", "Stationery", "Other",
}
