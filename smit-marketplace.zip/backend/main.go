package main

import (
	"log"

	"smitmarket/config"
	"smitmarket/routes"
)

func main() {
	cfg := config.Load()
	db := config.Connect(cfg)
	config.Seed(db, cfg)
	r := routes.Setup(db, cfg)
	log.Printf("Smit MarketPlace API listening on :%s (%s)", cfg.Port, cfg.Env)
	if err := r.Run(":" + cfg.Port); err != nil {
		log.Fatal(err)
	}
}
