package repositories

import (
	"strings"

	"smitmarket/models"

	"gorm.io/gorm"
)

type ProductFilter struct {
	Q          string
	CategoryID uint
	MinPaise   int64
	MaxPaise   int64
	Conditions []string
	Negotiable *bool
	Sort       string
	Page       int
	PageSize   int
	SellerID   uint
	Status     string // empty = active+reserved
}

// SearchProducts runs filtering, sorting and pagination in SQL.
func SearchProducts(db *gorm.DB, f ProductFilter) ([]models.Product, int64, error) {
	q := db.Model(&models.Product{})
	if f.SellerID != 0 {
		q = q.Where("products.seller_id = ?", f.SellerID)
	}
	if f.Status != "" {
		q = q.Where("products.status = ?", f.Status)
	} else {
		q = q.Where("products.status IN ?", []string{models.ProductActive, models.ProductReserved})
	}
	if s := strings.TrimSpace(f.Q); s != "" {
		like := "%" + strings.ToLower(s) + "%"
		q = q.Where("LOWER(products.title) LIKE ? OR LOWER(products.description) LIKE ?", like, like)
	}
	if f.CategoryID != 0 {
		q = q.Where("products.category_id = ?", f.CategoryID)
	}
	if f.MinPaise > 0 {
		q = q.Where("products.price_paise >= ?", f.MinPaise)
	}
	if f.MaxPaise > 0 {
		q = q.Where("products.price_paise <= ?", f.MaxPaise)
	}
	if len(f.Conditions) > 0 {
		q = q.Where("products.condition IN ?", f.Conditions)
	}
	if f.Negotiable != nil {
		q = q.Where("products.negotiable = ?", *f.Negotiable)
	}
	var total int64
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, err
	}
	switch f.Sort {
	case "price_asc":
		q = q.Order("products.price_paise ASC")
	case "price_desc":
		q = q.Order("products.price_paise DESC")
	default:
		q = q.Order("products.created_at DESC")
	}
	if f.Page < 1 {
		f.Page = 1
	}
	if f.PageSize < 1 || f.PageSize > 50 {
		f.PageSize = 12
	}
	var out []models.Product
	err := q.Preload("Images").Preload("Category").Preload("Seller").
		Limit(f.PageSize).Offset((f.Page - 1) * f.PageSize).Find(&out).Error
	return out, total, err
}

func AvgRating(db *gorm.DB, userID uint) (float64, int64) {
	var r struct {
		Avg *float64
		Cnt int64
	}
	db.Model(&models.Review{}).Select("AVG(rating) as avg, COUNT(*) as cnt").Where("reviewee_id = ?", userID).Scan(&r)
	if r.Avg == nil {
		return 0, 0
	}
	return *r.Avg, r.Cnt
}
