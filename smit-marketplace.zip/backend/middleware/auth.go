package middleware

import (
	"net/http"
	"strings"

	"smitmarket/models"
	"smitmarket/utils"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

const CtxUser = "currentUser"

// Auth validates the JWT and loads the user from the DB on every request, so
// suspended accounts and role changes take effect immediately.
func Auth(db *gorm.DB, secret string) gin.HandlerFunc {
	return func(c *gin.Context) {
		h := c.GetHeader("Authorization")
		if !strings.HasPrefix(h, "Bearer ") {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "authentication required"})
			return
		}
		claims, err := utils.ParseToken(secret, strings.TrimPrefix(h, "Bearer "))
		if err != nil {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "invalid or expired token"})
			return
		}
		var u models.User
		if err := db.First(&u, claims.UserID).Error; err != nil {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "user not found"})
			return
		}
		if u.AccountStatus == models.AccountSuspended {
			c.AbortWithStatusJSON(http.StatusForbidden, gin.H{"error": "account suspended"})
			return
		}
		c.Set(CtxUser, &u)
		c.Next()
	}
}

// OptionalAuth attaches the user if a valid token is present, but never blocks.
func OptionalAuth(db *gorm.DB, secret string) gin.HandlerFunc {
	return func(c *gin.Context) {
		h := c.GetHeader("Authorization")
		if strings.HasPrefix(h, "Bearer ") {
			if claims, err := utils.ParseToken(secret, strings.TrimPrefix(h, "Bearer ")); err == nil {
				var u models.User
				if db.First(&u, claims.UserID).Error == nil && u.AccountStatus == models.AccountActive {
					c.Set(CtxUser, &u)
				}
			}
		}
		c.Next()
	}
}

func RequireRole(role string) gin.HandlerFunc {
	return func(c *gin.Context) {
		u := Current(c)
		if u == nil || u.Role != role {
			c.AbortWithStatusJSON(http.StatusForbidden, gin.H{"error": "insufficient permissions"})
			return
		}
		c.Next()
	}
}

// RequireVerified blocks unverified students from trading actions.
func RequireVerified() gin.HandlerFunc {
	return func(c *gin.Context) {
		u := Current(c)
		if u == nil || (!u.VerificationStatus && u.Role != models.RoleAdmin) {
			c.AbortWithStatusJSON(http.StatusForbidden, gin.H{"error": "please verify your email first"})
			return
		}
		c.Next()
	}
}

func Current(c *gin.Context) *models.User {
	if v, ok := c.Get(CtxUser); ok {
		return v.(*models.User)
	}
	return nil
}
