package config

import (
	"log"
	"os"
	"strconv"

	"github.com/joho/godotenv"
)

type Config struct {
	Port           string
	Env            string
	JWTSecret      string
	FrontendOrigin string
	DBDriver       string
	DBDSN          string
	AdminEmail     string
	AdminPassword  string
	AdminName      string
	SMTPHost       string
	SMTPPort       string
	SMTPUser       string
	SMTPPass       string
	SMTPFrom       string
	UploadDir      string
	MaxUploadBytes int64
	SeedDemo       bool
}

func get(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}

func Load() *Config {
	_ = godotenv.Load()
	mb, _ := strconv.Atoi(get("MAX_UPLOAD_MB", "5"))
	c := &Config{
		Port:           get("PORT", "8080"),
		Env:            get("APP_ENV", "development"),
		JWTSecret:      os.Getenv("JWT_SECRET"),
		FrontendOrigin: get("FRONTEND_ORIGIN", "http://localhost:5173"),
		DBDriver:       get("DB_DRIVER", "sqlite"),
		DBDSN:          get("DB_DSN", "smitmarket.db"),
		AdminEmail:     os.Getenv("ADMIN_EMAIL"),
		AdminPassword:  os.Getenv("ADMIN_PASSWORD"),
		AdminName:      get("ADMIN_NAME", "Campus Admin"),
		SMTPHost:       os.Getenv("SMTP_HOST"),
		SMTPPort:       get("SMTP_PORT", "587"),
		SMTPUser:       os.Getenv("SMTP_USER"),
		SMTPPass:       os.Getenv("SMTP_PASS"),
		SMTPFrom:       get("SMTP_FROM", "no-reply@smit.edu"),
		UploadDir:      get("UPLOAD_DIR", "uploads"),
		MaxUploadBytes: int64(mb) * 1024 * 1024,
		SeedDemo:       get("SEED_DEMO", "false") == "true",
	}
	if c.JWTSecret == "" {
		if c.Env == "production" {
			log.Fatal("JWT_SECRET must be set in production")
		}
		log.Println("WARNING: JWT_SECRET not set; using an insecure development secret")
		c.JWTSecret = "dev-only-insecure-secret"
	}
	return c
}

func (c *Config) IsDev() bool { return c.Env != "production" }
