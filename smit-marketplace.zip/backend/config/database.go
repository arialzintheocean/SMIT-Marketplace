package config

import (
	"fmt"
	"log"
	"strings"

	"smitmarket/models"
	"smitmarket/utils"

	"github.com/glebarez/sqlite"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

// Connect opens the database. SQLite is used for development; to move to PostgreSQL,
// add gorm.io/driver/postgres and return postgres.Open(DSN) in the "postgres" case.
func Connect(c *Config) *gorm.DB {
	var dialector gorm.Dialector
	switch c.DBDriver {
	case "sqlite":
		dsn := c.DBDSN
		sep := "?"
		if strings.Contains(dsn, "?") {
			sep = "&"
		}
		dsn += sep + "_pragma=foreign_keys(1)&_pragma=busy_timeout(5000)&_pragma=journal_mode(WAL)"
		dialector = sqlite.Open(dsn)
	default:
		log.Fatalf("unsupported DB_DRIVER %q (see config/database.go to add PostgreSQL)", c.DBDriver)
	}
	db, err := gorm.Open(dialector, &gorm.Config{Logger: logger.Default.LogMode(logger.Warn)})
	if err != nil {
		log.Fatalf("database connection failed: %v", err)
	}
	if err := db.AutoMigrate(models.All()...); err != nil {
		log.Fatalf("migration failed: %v", err)
	}
	return db
}

func Seed(db *gorm.DB, c *Config) {
	for _, n := range models.CategoryNames {
		db.Where(models.Category{Name: n}).FirstOrCreate(&models.Category{Name: n})
	}
	if c.AdminEmail != "" && c.AdminPassword != "" {
		var cnt int64
		email := strings.ToLower(c.AdminEmail)
		db.Model(&models.User{}).Where("email = ?", email).Count(&cnt)
		if cnt == 0 {
			hash, _ := utils.HashPassword(c.AdminPassword)
			db.Create(&models.User{Name: c.AdminName, Email: email, PasswordHash: hash, Role: models.RoleAdmin,
				VerificationStatus: true, AccountStatus: models.AccountActive, College: "Administration"})
			log.Printf("initial admin account created: %s", email)
		}
	} else {
		log.Println("ADMIN_EMAIL / ADMIN_PASSWORD not set: no admin account created")
	}
	if c.SeedDemo {
		seedDemo(db)
	}
}

const demoPassword = "DemoPass#2026"

func seedDemo(db *gorm.DB) {
	var cnt int64
	db.Model(&models.User{}).Where("is_demo = ?", true).Count(&cnt)
	if cnt > 0 {
		return
	}
	hash, _ := utils.HashPassword(demoPassword)
	seller := models.User{Name: "Demo Seller (DEMO ACCOUNT)", Email: "demo.seller@demo.smit.edu", PasswordHash: hash,
		College: "Demo College", Department: "Computer Science", Year: 3, Role: models.RoleStudent,
		VerificationStatus: true, AccountStatus: models.AccountActive, IsDemo: true}
	buyer := models.User{Name: "Demo Buyer (DEMO ACCOUNT)", Email: "demo.buyer@demo.smit.edu", PasswordHash: hash,
		College: "Demo College", Department: "Mechanical Engineering", Year: 2, Role: models.RoleStudent,
		VerificationStatus: true, AccountStatus: models.AccountActive, IsDemo: true}
	db.Create(&seller)
	db.Create(&buyer)
	var cats []models.Category
	db.Order("id").Find(&cats)
	items := []struct {
		title, desc, cond, loc string
		price                  int64
		cat                    int
		neg                    bool
	}{
		{"[DEMO] Engineering Mathematics Textbook", "Demo listing. Clean copy with minimal highlighting.", "Good", "Central Library", 35000, 0, true},
		{"[DEMO] Scientific Calculator FX-991", "Demo listing. Works perfectly, includes cover.", "Like New", "Hostel Block A gate", 90000, 1, true},
		{"[DEMO] Study Table Lamp", "Demo listing. LED, adjustable arm.", "Good", "Main canteen", 40000, 2, false},
		{"[DEMO] Hero Sprint Cycle 26T", "Demo listing. Recently serviced.", "Fair", "Parking lot B", 350000, 4, true},
	}
	for _, it := range items {
		db.Create(&models.Product{SellerID: seller.ID, Title: it.title, Description: it.desc, PricePaise: it.price,
			CategoryID: cats[it.cat].ID, Condition: it.cond, Negotiable: it.neg, PickupLocation: it.loc, Status: models.ProductActive})
	}
	fmt.Printf("demo accounts created: demo.seller@demo.smit.edu / demo.buyer@demo.smit.edu (password %s)\n", demoPassword)
}
