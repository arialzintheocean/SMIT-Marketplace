package handlers

import (
	"io"
	"math"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"smitmarket/models"
	"smitmarket/repositories"
	"smitmarket/services"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

func valid(list []string, v string) bool {
	for _, x := range list {
		if x == v {
			return true
		}
	}
	return false
}

func rupeesToPaise(s string) (int64, bool) {
	f, err := strconv.ParseFloat(strings.TrimSpace(s), 64)
	if err != nil || f <= 0 || f > 10000000 {
		return 0, false
	}
	return int64(math.Round(f * 100)), true
}

func (h *Handler) Categories(c *gin.Context) {
	var cats []models.Category
	h.DB.Order("id").Find(&cats)
	c.JSON(200, gin.H{"categories": cats, "conditions": models.Conditions})
}

func (h *Handler) ListProducts(c *gin.Context) {
	f := repositories.ProductFilter{
		Q: c.Query("q"), Sort: c.Query("sort"),
		Page: intQuery(c, "page", 1), PageSize: intQuery(c, "pageSize", 12),
	}
	if v := intQuery(c, "category", 0); v > 0 {
		f.CategoryID = uint(v)
	}
	if v, ok := rupeesToPaise(c.Query("minPrice")); ok {
		f.MinPaise = v
	}
	if v, ok := rupeesToPaise(c.Query("maxPrice")); ok {
		f.MaxPaise = v
	}
	if cs := c.Query("condition"); cs != "" {
		for _, x := range strings.Split(cs, ",") {
			if valid(models.Conditions, x) {
				f.Conditions = append(f.Conditions, x)
			}
		}
	}
	if c.Query("negotiable") == "true" {
		t := true
		f.Negotiable = &t
	}
	items, total, err := repositories.SearchProducts(h.DB, f)
	if err != nil {
		fail(c, 500, "search failed")
		return
	}
	c.JSON(200, gin.H{"items": items, "total": total, "page": f.Page, "pageSize": f.PageSize,
		"totalPages": int(math.Ceil(float64(total) / float64(maxInt(f.PageSize, 1))))})
}

func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}

// MyProducts lists the signed-in seller's listings in any status.
func (h *Handler) MyProducts(c *gin.Context) {
	var items []models.Product
	q := h.DB.Preload("Images").Preload("Category").Where("seller_id = ? AND status <> ?", h.me(c).ID, models.ProductRemoved)
	if s := c.Query("status"); s != "" {
		q = q.Where("status = ?", s)
	}
	q.Order("created_at DESC").Find(&items)
	type row struct {
		models.Product
		Wishlisted int64 `json:"wishlisted"`
		Offers     int64 `json:"offers"`
		Chats      int64 `json:"chats"`
	}
	out := make([]row, 0, len(items))
	for _, p := range items {
		r := row{Product: p}
		h.DB.Model(&models.Wishlist{}).Where("product_id = ?", p.ID).Count(&r.Wishlisted)
		h.DB.Model(&models.Offer{}).Where("product_id = ? AND from_seller = ?", p.ID, false).Count(&r.Offers)
		h.DB.Model(&models.Conversation{}).Where("product_id = ?", p.ID).Count(&r.Chats)
		out = append(out, r)
	}
	c.JSON(200, gin.H{"items": out})
}

// ProductsByIDs powers "recently viewed".
func (h *Handler) ProductsByIDs(c *gin.Context) {
	var ids []uint
	for _, s := range strings.Split(c.Query("ids"), ",") {
		if n, err := strconv.Atoi(s); err == nil && n > 0 && len(ids) < 12 {
			ids = append(ids, uint(n))
		}
	}
	var items []models.Product
	if len(ids) > 0 {
		h.DB.Preload("Images").Preload("Category").
			Where("id IN ? AND status IN ?", ids, []string{models.ProductActive, models.ProductReserved}).Find(&items)
	}
	c.JSON(200, gin.H{"items": items})
}

func (h *Handler) GetProduct(c *gin.Context) {
	id, ok := idParam(c, "id")
	if !ok {
		return
	}
	var p models.Product
	if err := h.DB.Preload("Images").Preload("Category").Preload("Seller").First(&p, id).Error; err != nil {
		fail(c, 404, "listing not found")
		return
	}
	u := h.me(c)
	isOwner := u != nil && u.ID == p.SellerID
	isAdmin := u != nil && u.Role == models.RoleAdmin
	if p.Status == models.ProductRemoved && !isAdmin && !isOwner {
		fail(c, 404, "listing not found")
		return
	}
	if !isOwner {
		h.DB.Model(&models.Product{}).Where("id = ?", p.ID).UpdateColumn("views", gorm.Expr("views + 1"))
		p.Views++
	}
	avg, n := repositories.AvgRating(h.DB, p.SellerID)
	resp := gin.H{"product": p, "sellerRating": avg, "sellerReviews": n, "isOwner": isOwner}
	if u != nil {
		var cnt int64
		h.DB.Model(&models.Wishlist{}).Where("user_id = ? AND product_id = ?", u.ID, p.ID).Count(&cnt)
		resp["wishlisted"] = cnt > 0
	}
	c.JSON(200, resp)
}

type productInput struct {
	Title, Description, PickupLocation, Condition string
	Price                                         int64
	CategoryID                                    uint
	Negotiable                                    bool
}

func (h *Handler) parseProduct(c *gin.Context) (*productInput, string) {
	in := &productInput{
		Title: strings.TrimSpace(c.PostForm("title")), Description: strings.TrimSpace(c.PostForm("description")),
		PickupLocation: strings.TrimSpace(c.PostForm("pickupLocation")), Condition: c.PostForm("condition"),
		Negotiable: c.PostForm("negotiable") == "true",
	}
	if len(in.Title) < 3 || len(in.Title) > 150 {
		return nil, "title must be 3-150 characters"
	}
	if len(in.Description) > 3000 {
		return nil, "description too long"
	}
	p, ok := rupeesToPaise(c.PostForm("price"))
	if !ok {
		return nil, "enter a valid price in INR"
	}
	in.Price = p
	if !valid(models.Conditions, in.Condition) {
		return nil, "invalid condition"
	}
	cid, _ := strconv.Atoi(c.PostForm("categoryId"))
	var cnt int64
	h.DB.Model(&models.Category{}).Where("id = ?", cid).Count(&cnt)
	if cnt == 0 {
		return nil, "invalid category"
	}
	in.CategoryID = uint(cid)
	if in.PickupLocation == "" {
		return nil, "pickup location is required"
	}
	return in, ""
}

func (h *Handler) saveImages(c *gin.Context) ([]string, error) {
	form, err := c.MultipartForm()
	if err != nil {
		return nil, nil
	}
	files := form.File["images"]
	if len(files) > 6 {
		return nil, errString("you can upload at most 6 images")
	}
	var paths []string
	for _, fh := range files {
		fh := fh
		p, err := h.storeFile(fh.Filename, fh.Size, func() (io.ReadCloser, error) { return fh.Open() })
		if err != nil {
			for _, x := range paths {
				os.Remove(filepath.Join(h.Cfg.UploadDir, filepath.Base(x)))
			}
			return nil, err
		}
		paths = append(paths, p)
	}
	return paths, nil
}

type errString string

func (e errString) Error() string { return string(e) }

func (h *Handler) CreateProduct(c *gin.Context) {
	in, msg := h.parseProduct(c)
	if msg != "" {
		fail(c, 400, msg)
		return
	}
	paths, err := h.saveImages(c)
	if err != nil {
		fail(c, 400, err.Error())
		return
	}
	if len(paths) == 0 {
		fail(c, 400, "add at least one product image")
		return
	}
	p := models.Product{SellerID: h.me(c).ID, Title: in.Title, Description: in.Description, PricePaise: in.Price,
		CategoryID: in.CategoryID, Condition: in.Condition, Negotiable: in.Negotiable, PickupLocation: in.PickupLocation,
		Status: models.ProductActive}
	err = h.DB.Transaction(func(tx *gorm.DB) error {
		if err := tx.Create(&p).Error; err != nil {
			return err
		}
		for _, x := range paths {
			if err := tx.Create(&models.ProductImage{ProductID: p.ID, ImagePath: x}).Error; err != nil {
				return err
			}
		}
		return nil
	})
	if err != nil {
		fail(c, 500, "could not create listing")
		return
	}
	h.DB.Preload("Images").First(&p, p.ID)
	c.JSON(http.StatusCreated, p)
}

func (h *Handler) ownedProduct(c *gin.Context) (*models.Product, bool) {
	id, ok := idParam(c, "id")
	if !ok {
		return nil, false
	}
	var p models.Product
	if err := h.DB.Preload("Images").First(&p, id).Error; err != nil {
		fail(c, 404, "listing not found")
		return nil, false
	}
	if p.SellerID != h.me(c).ID {
		fail(c, 403, "you can only modify your own listings")
		return nil, false
	}
	return &p, true
}

func (h *Handler) UpdateProduct(c *gin.Context) {
	p, ok := h.ownedProduct(c)
	if !ok {
		return
	}
	if p.Status == models.ProductSold || p.Status == models.ProductRemoved {
		fail(c, 409, "sold or removed listings cannot be edited")
		return
	}
	in, msg := h.parseProduct(c)
	if msg != "" {
		fail(c, 400, msg)
		return
	}
	newPaths, err := h.saveImages(c)
	if err != nil {
		fail(c, 400, err.Error())
		return
	}
	remove := map[uint]bool{}
	for _, s := range strings.Split(c.PostForm("removeImages"), ",") {
		if n, e := strconv.Atoi(s); e == nil {
			remove[uint(n)] = true
		}
	}
	remaining := 0
	for _, im := range p.Images {
		if !remove[im.ID] {
			remaining++
		}
	}
	if remaining+len(newPaths) == 0 {
		fail(c, 400, "a listing needs at least one image")
		return
	}
	if remaining+len(newPaths) > 6 {
		fail(c, 400, "a listing can have at most 6 images")
		return
	}
	err = h.DB.Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(p).Updates(map[string]interface{}{"title": in.Title, "description": in.Description,
			"price_paise": in.Price, "category_id": in.CategoryID, "condition": in.Condition,
			"negotiable": in.Negotiable, "pickup_location": in.PickupLocation}).Error; err != nil {
			return err
		}
		for _, im := range p.Images {
			if remove[im.ID] {
				if err := tx.Delete(&models.ProductImage{}, im.ID).Error; err != nil {
					return err
				}
				os.Remove(filepath.Join(h.Cfg.UploadDir, filepath.Base(im.ImagePath)))
			}
		}
		for _, x := range newPaths {
			if err := tx.Create(&models.ProductImage{ProductID: p.ID, ImagePath: x}).Error; err != nil {
				return err
			}
		}
		return nil
	})
	if err != nil {
		fail(c, 500, "could not update listing")
		return
	}
	h.DB.Preload("Images").First(p, p.ID)
	c.JSON(200, p)
}

func (h *Handler) DeleteProduct(c *gin.Context) {
	p, ok := h.ownedProduct(c)
	if !ok {
		return
	}
	var active int64
	h.DB.Model(&models.Transaction{}).Where("product_id = ? AND status IN ?", p.ID,
		[]string{models.TxAccepted, models.TxReserved}).Count(&active)
	if active > 0 {
		fail(c, 409, "this listing has a reserved exchange in progress; cancel it first")
		return
	}
	var hist int64
	h.DB.Model(&models.Transaction{}).Where("product_id = ? AND status = ?", p.ID, models.TxCompleted).Count(&hist)
	if hist > 0 || p.Status == models.ProductSold {
		fail(c, 409, "sold listings are kept for transaction history")
		return
	}
	// Soft-remove so offers/conversations/reports keep valid references.
	h.DB.Transaction(func(tx *gorm.DB) error {
		tx.Model(p).Update("status", models.ProductRemoved)
		tx.Model(&models.Offer{}).Where("product_id = ? AND status IN ?", p.ID,
			[]string{models.OfferPending, models.OfferCountered}).Update("status", models.OfferWithdrawn)
		tx.Model(&models.Transaction{}).Where("product_id = ? AND status = ?", p.ID, models.TxRequested).
			Update("status", models.TxCancelled)
		tx.Where("product_id = ?", p.ID).Delete(&models.Wishlist{})
		return nil
	})
	c.JSON(200, gin.H{"message": "listing deleted"})
}

// SetProductStatus lets the owner switch between active / reserved / sold.
func (h *Handler) SetProductStatus(c *gin.Context) {
	p, ok := h.ownedProduct(c)
	if !ok {
		return
	}
	var r struct {
		Status string `json:"status"`
	}
	if c.ShouldBindJSON(&r) != nil || !valid([]string{models.ProductActive, models.ProductReserved, models.ProductSold}, r.Status) {
		fail(c, 400, "status must be active, reserved or sold")
		return
	}
	if p.Status == models.ProductSold || p.Status == models.ProductRemoved {
		fail(c, 409, "this listing is already "+p.Status)
		return
	}
	if r.Status == models.ProductActive {
		var held int64
		h.DB.Model(&models.Transaction{}).Where("product_id = ? AND status IN ?", p.ID,
			[]string{models.TxAccepted, models.TxReserved}).Count(&held)
		if held > 0 {
			fail(c, 409, "cancel the reserved exchange before re-listing")
			return
		}
	}
	err := h.DB.Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(p).Update("status", r.Status).Error; err != nil {
			return err
		}
		if r.Status == models.ProductSold {
			return h.closeOutSale(tx, p)
		}
		return nil
	})
	if err != nil {
		fail(c, 500, "could not update status")
		return
	}
	c.JSON(200, gin.H{"status": r.Status})
}

// closeOutSale completes any reserved exchange and closes every other open offer/request.
func (h *Handler) closeOutSale(tx *gorm.DB, p *models.Product) error {
	if err := tx.Model(&models.Transaction{}).Where("product_id = ? AND status IN ?", p.ID,
		[]string{models.TxAccepted, models.TxReserved}).
		Updates(map[string]interface{}{"status": models.TxCompleted, "completed_at": gorm.Expr("CURRENT_TIMESTAMP")}).Error; err != nil {
		return err
	}
	var others []models.Transaction
	tx.Where("product_id = ? AND status = ?", p.ID, models.TxRequested).Find(&others)
	for _, t := range others {
		tx.Model(&t).Update("status", models.TxRejected)
		services.Notify(tx, t.BuyerID, "Listing sold", "\""+p.Title+"\" was sold to another buyer.", "/transactions")
	}
	return tx.Model(&models.Offer{}).Where("product_id = ? AND status IN ?", p.ID,
		[]string{models.OfferPending, models.OfferCountered}).Update("status", models.OfferRejected).Error
}

// Interested lists buyers who wishlisted, chatted, or made offers (owner only).
func (h *Handler) Interested(c *gin.Context) {
	p, ok := h.ownedProduct(c)
	if !ok {
		return
	}
	ids := map[uint]bool{}
	var tmp []uint
	h.DB.Model(&models.Wishlist{}).Where("product_id = ?", p.ID).Pluck("user_id", &tmp)
	for _, i := range tmp {
		ids[i] = true
	}
	h.DB.Model(&models.Offer{}).Where("product_id = ?", p.ID).Pluck("buyer_id", &tmp)
	for _, i := range tmp {
		ids[i] = true
	}
	h.DB.Model(&models.Conversation{}).Where("product_id = ?", p.ID).Pluck("buyer_id", &tmp)
	for _, i := range tmp {
		ids[i] = true
	}
	h.DB.Model(&models.Transaction{}).Where("product_id = ?", p.ID).Pluck("buyer_id", &tmp)
	for _, i := range tmp {
		ids[i] = true
	}
	var list []uint
	for i := range ids {
		list = append(list, i)
	}
	var users []models.User
	if len(list) > 0 {
		h.DB.Where("id IN ?", list).Find(&users)
	}
	c.JSON(200, gin.H{"items": users})
}
