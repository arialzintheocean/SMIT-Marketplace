package handlers

import (
	"strings"
	"time"

	"smitmarket/models"
	"smitmarket/services"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

func (h *Handler) CreateTransaction(c *gin.Context) {
	var r struct {
		ProductID uint   `json:"productId"`
		Message   string `json:"message"`
	}
	if c.ShouldBindJSON(&r) != nil {
		fail(c, 400, "invalid request")
		return
	}
	u := h.me(c)
	var p models.Product
	if h.DB.First(&p, r.ProductID).Error != nil {
		fail(c, 404, "listing not found")
		return
	}
	if p.SellerID == u.ID {
		fail(c, 400, "you cannot buy your own listing")
		return
	}
	if p.Status != models.ProductActive {
		fail(c, 409, "this listing is not available for purchase requests")
		return
	}
	var open int64
	h.DB.Model(&models.Transaction{}).Where("product_id = ? AND buyer_id = ? AND status IN ?", p.ID, u.ID,
		[]string{models.TxRequested, models.TxReserved}).Count(&open)
	if open > 0 {
		fail(c, 409, "you already have an open request for this listing")
		return
	}
	t := models.Transaction{ProductID: p.ID, BuyerID: u.ID, SellerID: p.SellerID, FinalPricePaise: p.PricePaise, Status: models.TxRequested}
	if err := h.DB.Create(&t).Error; err != nil {
		fail(c, 500, "could not send request")
		return
	}
	services.Notify(h.DB, p.SellerID, "Purchase request", u.Name+" wants to buy \""+p.Title+"\" for ₹"+rupees(p.PricePaise), "/transactions")
	c.JSON(201, t)
}

type txView struct {
	models.Transaction
	MyReviewed bool `json:"myReviewed"`
}

func (h *Handler) ListTransactions(c *gin.Context) {
	u := h.me(c)
	q := h.DB.Preload("Product.Images").Preload("Buyer").Preload("Seller")
	switch c.Query("role") {
	case "buyer":
		q = q.Where("buyer_id = ?", u.ID)
	case "seller":
		q = q.Where("seller_id = ?", u.ID)
	default:
		q = q.Where("buyer_id = ? OR seller_id = ?", u.ID, u.ID)
	}
	var rows []models.Transaction
	q.Order("created_at DESC").Find(&rows)
	out := make([]txView, 0, len(rows))
	for _, t := range rows {
		var n int64
		h.DB.Model(&models.Review{}).Where("transaction_id = ? AND reviewer_id = ?", t.ID, u.ID).Count(&n)
		out = append(out, txView{t, n > 0})
	}
	c.JSON(200, gin.H{"items": out})
}

// UpdateTransactionStatus drives the exchange workflow.
// Seller "accepted" on a request atomically reserves the listing and stores status "reserved".
func (h *Handler) UpdateTransactionStatus(c *gin.Context) {
	id, ok := idParam(c, "id")
	if !ok {
		return
	}
	var r struct {
		Status string `json:"status"`
	}
	if c.ShouldBindJSON(&r) != nil {
		fail(c, 400, "invalid request")
		return
	}
	u := h.me(c)
	var t models.Transaction
	if h.DB.First(&t, id).Error != nil || (t.BuyerID != u.ID && t.SellerID != u.ID) {
		fail(c, 404, "transaction not found")
		return
	}
	isSeller := t.SellerID == u.ID
	var p models.Product
	h.DB.First(&p, t.ProductID)
	other := t.BuyerID
	if !isSeller {
		other = t.SellerID
	}
	deny := func() { fail(c, 403, "you cannot perform this action in the current state") }
	err := h.DB.Transaction(func(tx *gorm.DB) error {
		switch {
		case t.Status == models.TxRequested && r.Status == models.TxAccepted && isSeller:
			if _, err := h.reserveDeal(tx, &p, t.BuyerID, t.FinalPricePaise, &t); err != nil {
				return err
			}
			services.Notify(tx, other, "Request accepted", "\""+p.Title+"\" is reserved for you. Arrange campus pickup at "+p.PickupLocation+".", "/transactions")
		case t.Status == models.TxRequested && r.Status == models.TxRejected && isSeller:
			tx.Model(&t).Update("status", models.TxRejected)
			services.Notify(tx, other, "Request declined", "Your request for \""+p.Title+"\" was declined.", "/transactions")
		case t.Status == models.TxRequested && r.Status == models.TxCancelled && !isSeller:
			tx.Model(&t).Update("status", models.TxCancelled)
			services.Notify(tx, other, "Request cancelled", u.Name+" cancelled the request for \""+p.Title+"\".", "/transactions")
		case t.Status == models.TxReserved && r.Status == models.TxCompleted && isSeller:
			now := time.Now()
			if err := tx.Model(&t).Updates(map[string]interface{}{"status": models.TxCompleted, "completed_at": now}).Error; err != nil {
				return err
			}
			if err := tx.Model(&p).Update("status", models.ProductSold).Error; err != nil {
				return err
			}
			if err := h.closeOutSale(tx, &p); err != nil {
				return err
			}
			services.Notify(tx, other, "Exchange completed", "\""+p.Title+"\" is marked as sold. Please leave a review.", "/transactions")
		case t.Status == models.TxReserved && r.Status == models.TxCancelled:
			tx.Model(&t).Update("status", models.TxCancelled)
			tx.Model(&p).Where("status = ?", models.ProductReserved).Update("status", models.ProductActive)
			services.Notify(tx, other, "Exchange cancelled", u.Name+" cancelled the exchange for \""+p.Title+"\". The listing is available again.", "/transactions")
		default:
			return errString("__deny__")
		}
		return nil
	})
	if err != nil {
		if strings.Contains(err.Error(), "__deny__") {
			deny()
		} else if _, isMsg := err.(errString); isMsg {
			fail(c, 409, err.Error())
		} else {
			fail(c, 500, "could not update transaction")
		}
		return
	}
	h.DB.Preload("Product").First(&t, t.ID)
	c.JSON(200, t)
}
