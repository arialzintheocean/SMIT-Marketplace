package handlers

import (
	"fmt"
	"io"
	"log"
	"net/http"
	"net/mail"
	"os"
	"path/filepath"
	"strings"
	"time"

	"smitmarket/models"
	"smitmarket/repositories"
	"smitmarket/utils"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

var allowedImages = map[string]string{"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp", "image/gif": ".gif"}

type userView struct {
	models.User
	AvgRating   float64 `json:"avgRating"`
	ReviewCount int64   `json:"reviewCount"`
}

func (h *Handler) view(u *models.User) userView {
	avg, n := repositories.AvgRating(h.DB, u.ID)
	return userView{User: *u, AvgRating: avg, ReviewCount: n}
}

type registerReq struct {
	Name       string `form:"name" json:"name"`
	Email      string `form:"email" json:"email"`
	Password   string `form:"password" json:"password"`
	College    string `form:"college" json:"college"`
	Department string `form:"department" json:"department"`
	Year       int    `form:"year" json:"year"`
}

func (h *Handler) issueOTP(u *models.User) (string, error) {
	otp := utils.GenerateOTP()
	u.OTPHash = utils.HashOTP(otp)
	u.OTPExpiresAt = time.Now().Add(10 * time.Minute)
	if err := h.DB.Model(u).Updates(map[string]interface{}{"otp_hash": u.OTPHash, "otp_expires_at": u.OTPExpiresAt}).Error; err != nil {
		return "", err
	}
	body := fmt.Sprintf("Your Smit MarketPlace verification code is %s. It expires in 10 minutes.", otp)
	if err := utils.SendMail(h.Cfg.SMTPHost, h.Cfg.SMTPPort, h.Cfg.SMTPUser, h.Cfg.SMTPPass, h.Cfg.SMTPFrom, u.Email, "Verify your Smit MarketPlace account", body); err != nil {
		if h.Cfg.IsDev() {
			log.Printf("[DEV] OTP for %s: %s (email not sent: %v)", u.Email, otp, err)
			return otp, nil
		}
		log.Printf("failed to send OTP email to %s: %v", u.Email, err)
		return "", nil
	}
	return "", nil
}

func (h *Handler) Register(c *gin.Context) {
	var r registerReq
	if err := c.ShouldBind(&r); err != nil {
		fail(c, 400, "invalid request")
		return
	}
	r.Name = strings.TrimSpace(r.Name)
	r.Email = strings.ToLower(strings.TrimSpace(r.Email))
	if len(r.Name) < 2 || len(r.Name) > 100 {
		fail(c, 400, "name must be 2-100 characters")
		return
	}
	if _, err := mail.ParseAddress(r.Email); err != nil {
		fail(c, 400, "invalid email address")
		return
	}
	if len(r.Password) < 8 {
		fail(c, 400, "password must be at least 8 characters")
		return
	}
	if r.Year < 1 || r.Year > 6 {
		fail(c, 400, "year of study must be between 1 and 6")
		return
	}
	hash, err := utils.HashPassword(r.Password)
	if err != nil {
		fail(c, 500, "could not process password")
		return
	}
	u := models.User{Name: r.Name, Email: r.Email, PasswordHash: hash, College: strings.TrimSpace(r.College),
		Department: strings.TrimSpace(r.Department), Year: r.Year, Role: models.RoleStudent, AccountStatus: models.AccountActive}
	if fh, err := c.FormFile("profileImage"); err == nil {
		p, err := h.storeFile(fh.Filename, fh.Size, func() (io.ReadCloser, error) { return fh.Open() })
		if err != nil {
			fail(c, 400, err.Error())
			return
		}
		u.ProfileImage = p
	}
	if err := h.DB.Create(&u).Error; err != nil {
		if strings.Contains(strings.ToLower(err.Error()), "unique") {
			fail(c, 409, "an account with this email already exists")
			return
		}
		fail(c, 500, "could not create account")
		return
	}
	devOTP, _ := h.issueOTP(&u)
	resp := gin.H{"message": "registered; check your email for the verification code", "email": u.Email}
	if devOTP != "" {
		resp["dev_otp"] = devOTP
	}
	c.JSON(http.StatusCreated, resp)
}

func (h *Handler) ResendOTP(c *gin.Context) {
	var r struct {
		Email string `json:"email"`
	}
	if c.ShouldBindJSON(&r) != nil {
		fail(c, 400, "invalid request")
		return
	}
	var u models.User
	if h.DB.Where("email = ?", strings.ToLower(strings.TrimSpace(r.Email))).First(&u).Error != nil || u.VerificationStatus {
		c.JSON(200, gin.H{"message": "if the account needs verification, a new code was sent"})
		return
	}
	devOTP, _ := h.issueOTP(&u)
	resp := gin.H{"message": "if the account needs verification, a new code was sent"}
	if devOTP != "" {
		resp["dev_otp"] = devOTP
	}
	c.JSON(200, resp)
}

func (h *Handler) VerifyEmail(c *gin.Context) {
	var r struct {
		Email string `json:"email"`
		OTP   string `json:"otp"`
	}
	if c.ShouldBindJSON(&r) != nil {
		fail(c, 400, "invalid request")
		return
	}
	var u models.User
	if h.DB.Where("email = ?", strings.ToLower(strings.TrimSpace(r.Email))).First(&u).Error != nil {
		fail(c, 400, "invalid code")
		return
	}
	if u.VerificationStatus {
		c.JSON(200, gin.H{"message": "already verified"})
		return
	}
	if u.OTPHash == "" || time.Now().After(u.OTPExpiresAt) || u.OTPHash != utils.HashOTP(strings.TrimSpace(r.OTP)) {
		fail(c, 400, "invalid or expired code")
		return
	}
	h.DB.Model(&u).Updates(map[string]interface{}{"verification_status": true, "otp_hash": ""})
	c.JSON(200, gin.H{"message": "email verified, you can now log in"})
}

func (h *Handler) Login(c *gin.Context) {
	var r struct {
		Email    string `json:"email"`
		Password string `json:"password"`
	}
	if c.ShouldBindJSON(&r) != nil {
		fail(c, 400, "invalid request")
		return
	}
	var u models.User
	err := h.DB.Where("email = ?", strings.ToLower(strings.TrimSpace(r.Email))).First(&u).Error
	if err != nil || !utils.CheckPassword(u.PasswordHash, r.Password) {
		fail(c, 401, "incorrect email or password")
		return
	}
	if u.AccountStatus == models.AccountSuspended {
		fail(c, 403, "this account has been suspended")
		return
	}
	if !u.VerificationStatus {
		c.AbortWithStatusJSON(403, gin.H{"error": "email not verified", "needsVerification": true, "email": u.Email})
		return
	}
	tok, err := utils.MakeToken(h.Cfg.JWTSecret, u.ID, u.Role)
	if err != nil {
		fail(c, 500, "could not create session")
		return
	}
	c.JSON(200, gin.H{"token": tok, "user": h.view(&u)})
}

func (h *Handler) Me(c *gin.Context) { c.JSON(200, h.view(h.me(c))) }

func (h *Handler) UpdateProfile(c *gin.Context) {
	u := h.me(c)
	updates := map[string]interface{}{}
	if v := strings.TrimSpace(c.PostForm("name")); v != "" {
		if len(v) > 100 {
			fail(c, 400, "name too long")
			return
		}
		updates["name"] = v
	}
	if _, ok := c.GetPostForm("college"); ok {
		updates["college"] = strings.TrimSpace(c.PostForm("college"))
	}
	if _, ok := c.GetPostForm("department"); ok {
		updates["department"] = strings.TrimSpace(c.PostForm("department"))
	}
	if v := c.PostForm("year"); v != "" {
		var y int
		fmt.Sscanf(v, "%d", &y)
		if y < 1 || y > 6 {
			fail(c, 400, "year must be between 1 and 6")
			return
		}
		updates["year"] = y
	}
	if fh, err := c.FormFile("profileImage"); err == nil {
		p, err := h.storeFile(fh.Filename, fh.Size, func() (io.ReadCloser, error) { return fh.Open() })
		if err != nil {
			fail(c, 400, err.Error())
			return
		}
		updates["profile_image"] = p
	}
	if len(updates) > 0 {
		if err := h.DB.Model(u).Updates(updates).Error; err != nil {
			fail(c, 500, "could not update profile")
			return
		}
	}
	h.DB.First(u, u.ID)
	c.JSON(200, h.view(u))
}

// storeFile validates by sniffing the first 512 bytes, enforces size, writes to UPLOAD_DIR.
func (h *Handler) storeFile(name string, size int64, open func() (io.ReadCloser, error)) (string, error) {
	if size > h.Cfg.MaxUploadBytes {
		return "", fmt.Errorf("image %q exceeds the %d MB limit", name, h.Cfg.MaxUploadBytes/1024/1024)
	}
	f, err := open()
	if err != nil {
		return "", fmt.Errorf("could not read upload")
	}
	defer f.Close()
	buf := make([]byte, 512)
	n, _ := io.ReadFull(f, buf)
	ext, ok := allowedImages[http.DetectContentType(buf[:n])]
	if !ok {
		return "", fmt.Errorf("only JPG, PNG, WEBP or GIF images are allowed")
	}
	if err := os.MkdirAll(h.Cfg.UploadDir, 0o755); err != nil {
		return "", fmt.Errorf("storage unavailable")
	}
	fname := utils.RandomName() + ext
	out, err := os.Create(filepath.Join(h.Cfg.UploadDir, fname))
	if err != nil {
		return "", fmt.Errorf("could not save image")
	}
	defer out.Close()
	if _, err := out.Write(buf[:n]); err != nil {
		return "", fmt.Errorf("could not save image")
	}
	if _, err := io.Copy(out, io.LimitReader(f, h.Cfg.MaxUploadBytes)); err != nil {
		return "", fmt.Errorf("could not save image")
	}
	return "/uploads/" + fname, nil
}

// ensure gorm import used
var _ = gorm.ErrRecordNotFound
