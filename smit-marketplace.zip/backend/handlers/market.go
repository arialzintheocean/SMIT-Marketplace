package handlers

import (
	"math"
	"strings"

	"smitmarket/models"
	"smitmarket/services"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// ---------- Wishlist ----------

func (h *Handler) GetWishlist(c *gin.Context) {
	var rows []models.Wishlist
	h.DB.Preload("Product.Images").Preload("Product.Category").
		Where("user_id = ?", h.me(c).ID).Order("created_at DESC").Find(&rows)
	type item struct {
		models.Wishlist
		Available bool `json:"available"`
	}
	out := make([]item, 0, len(rows))
	for _, w := range rows {
		out = append(out, item{w, w.Product != nil && w.Product.Status == models.ProductActive})
	}
	c.JSON(200, gin.H{"items": out})
}

func (h *Handler) AddWishlist(c *gin.Context) {
	pid, ok := idParam(c, "productId")
	if !ok {
		return
	}
	u := h.me(c)
	var p models.Product
	if h.DB.First(&p, pid).Error != nil || p.Status == models.ProductRemoved {
		fail(c, 404, "listing not found")
		return
	}
	if p.SellerID == u.ID {
		fail(c, 400, "you cannot save your own listing")
		return
	}
	var cnt int64
	h.DB.Model(&models.Wishlist{}).Where("user_id = ? AND product_id = ?", u.ID, pid).Count(&cnt)
	if cnt > 0 {
		c.JSON(200, gin.H{"message": "already in wishlist"})
		return
	}
	if err := h.DB.Create(&models.Wishlist{UserID: u.ID, ProductID: pid}).Error; err != nil {
		c.JSON(200, gin.H{"message": "already in wishlist"}) // unique constraint race
		return
	}
	c.JSON(201, gin.H{"message": "added to wishlist"})
}

func (h *Handler) RemoveWishlist(c *gin.Context) {
	pid, ok := idParam(c, "productId")
	if !ok {
		return
	}
	h.DB.Where("user_id = ? AND product_id = ?", h.me(c).ID, pid).Delete(&models.Wishlist{})
	c.JSON(200, gin.H{"message": "removed"})
}

// ---------- Deal helper ----------

// reserveDeal atomically reserves the listing for a buyer and creates/updates the transaction.
// Must run inside a DB transaction. The conditional UPDATE guarantees only one buyer can win.
func (h *Handler) reserveDeal(tx *gorm.DB, p *models.Product, buyerID uint, price int64, existing *models.Transaction) (*models.Transaction, error) {
	res := tx.Model(&models.Product{}).Where("id = ? AND status = ?", p.ID, models.ProductActive).
		Update("status", models.ProductReserved)
	if res.Error != nil {
		return nil, res.Error
	}
	if res.RowsAffected != 1 {
		return nil, errString("this listing is no longer available")
	}
	var t models.Transaction
	if existing != nil {
		t = *existing
		if err := tx.Model(&t).Updates(map[string]interface{}{"status": models.TxReserved, "final_price_paise": price}).Error; err != nil {
			return nil, err
		}
		t.Status, t.FinalPricePaise = models.TxReserved, price
	} else {
		t = models.Transaction{ProductID: p.ID, BuyerID: buyerID, SellerID: p.SellerID, FinalPricePaise: price, Status: models.TxReserved}
		if err := tx.Create(&t).Error; err != nil {
			return nil, err
		}
	}
	// Close every other open request/offer on this listing.
	var others []models.Transaction
	tx.Where("product_id = ? AND status = ? AND id <> ?", p.ID, models.TxRequested, t.ID).Find(&others)
	for _, o := range others {
		tx.Model(&o).Update("status", models.TxRejected)
		services.Notify(tx, o.BuyerID, "Listing reserved", "\""+p.Title+"\" was reserved for another buyer.", "/transactions")
	}
	var openOffers []models.Offer
	tx.Where("product_id = ? AND status IN ?", p.ID, []string{models.OfferPending, models.OfferCountered}).Find(&openOffers)
	for _, o := range openOffers {
		if o.BuyerID != buyerID || o.Status == models.OfferCountered {
			tx.Model(&o).Update("status", models.OfferRejected)
		}
	}
	return &t, nil
}

// ---------- Offers ----------

type offerThread struct {
	models.Offer
	History []models.Offer `json:"history"`
}

func (h *Handler) CreateOffer(c *gin.Context) {
	var r struct {
		ProductID uint    `json:"productId"`
		Price     float64 `json:"price"`
		Message   string  `json:"message"`
	}
	if c.ShouldBindJSON(&r) != nil {
		fail(c, 400, "invalid request")
		return
	}
	u := h.me(c)
	var p models.Product
	if h.DB.First(&p, r.ProductID).Error != nil {
		fail(c, 404, "listing not found")
		return
	}
	if p.SellerID == u.ID {
		fail(c, 400, "you cannot make an offer on your own listing")
		return
	}
	if p.Status != models.ProductActive {
		fail(c, 409, "this listing is not accepting offers")
		return
	}
	if !p.Negotiable {
		fail(c, 400, "the seller has set a fixed price; send a purchase request instead")
		return
	}
	paise := int64(math.Round(r.Price * 100))
	if paise <= 0 || paise >= p.PricePaise {
		fail(c, 400, "offer must be above ₹0 and below the listed price")
		return
	}
	if len(r.Message) > 500 {
		fail(c, 400, "message too long")
		return
	}
	var open int64
	h.DB.Model(&models.Offer{}).Where("product_id = ? AND buyer_id = ? AND parent_offer_id IS NULL AND status IN ?",
		p.ID, u.ID, []string{models.OfferPending, models.OfferCountered}).Count(&open)
	if open > 0 {
		fail(c, 409, "you already have an open offer on this listing; withdraw it first")
		return
	}
	o := models.Offer{ProductID: p.ID, BuyerID: u.ID, OfferedPricePaise: paise, Message: strings.TrimSpace(r.Message), Status: models.OfferPending}
	if err := h.DB.Create(&o).Error; err != nil {
		fail(c, 500, "could not submit offer")
		return
	}
	services.Notify(h.DB, p.SellerID, "New offer", u.Name+" offered ₹"+rupees(paise)+" for \""+p.Title+"\"", "/offers")
	c.JSON(201, o)
}

func rupees(paise int64) string {
	whole := paise / 100
	frac := paise % 100
	if frac == 0 {
		return itoa(whole)
	}
	s := itoa(whole) + "."
	if frac < 10 {
		s += "0"
	}
	return s + itoa(frac)
}

func itoa(n int64) string {
	if n == 0 {
		return "0"
	}
	var b []byte
	for n > 0 {
		b = append([]byte{byte('0' + n%10)}, b...)
		n /= 10
	}
	return string(b)
}

func (h *Handler) threads(roots []models.Offer) []offerThread {
	out := make([]offerThread, 0, len(roots))
	for _, r := range roots {
		var hist []models.Offer
		h.DB.Where("parent_offer_id = ?", r.ID).Order("created_at").Find(&hist)
		out = append(out, offerThread{r, hist})
	}
	return out
}

func (h *Handler) OffersReceived(c *gin.Context) {
	var roots []models.Offer
	h.DB.Preload("Product.Images").Preload("Buyer").
		Where("parent_offer_id IS NULL AND product_id IN (?)",
			h.DB.Model(&models.Product{}).Select("id").Where("seller_id = ?", h.me(c).ID)).
		Order("created_at DESC").Find(&roots)
	c.JSON(200, gin.H{"items": h.threads(roots)})
}

func (h *Handler) OffersSent(c *gin.Context) {
	var roots []models.Offer
	h.DB.Preload("Product.Images").Preload("Product.Seller").
		Where("parent_offer_id IS NULL AND buyer_id = ?", h.me(c).ID).Order("created_at DESC").Find(&roots)
	c.JSON(200, gin.H{"items": h.threads(roots)})
}

// RespondOffer: the seller responds to buyer offers (accept/reject/counter);
// the buyer responds to seller counters (accept/reject).
func (h *Handler) RespondOffer(c *gin.Context) {
	id, ok := idParam(c, "id")
	if !ok {
		return
	}
	var r struct {
		Action  string  `json:"action"`
		Price   float64 `json:"price"`
		Message string  `json:"message"`
	}
	if c.ShouldBindJSON(&r) != nil || !valid([]string{"accept", "reject", "counter"}, r.Action) {
		fail(c, 400, "action must be accept, reject or counter")
		return
	}
	u := h.me(c)
	var o models.Offer
	if h.DB.First(&o, id).Error != nil {
		fail(c, 404, "offer not found")
		return
	}
	var p models.Product
	h.DB.First(&p, o.ProductID)
	// who is allowed to respond?
	responderIsSeller := !o.FromSeller
	if responderIsSeller && p.SellerID != u.ID || !responderIsSeller && o.BuyerID != u.ID {
		fail(c, 403, "you cannot respond to this offer")
		return
	}
	if o.Status != models.OfferPending {
		fail(c, 409, "this offer has already been "+o.Status)
		return
	}
	if p.Status != models.ProductActive {
		fail(c, 409, "this listing is no longer available")
		return
	}
	if r.Action == "counter" && !responderIsSeller {
		fail(c, 400, "buyers can only accept or reject a counter-offer; make a new offer instead")
		return
	}
	otherParty := o.BuyerID
	if !responderIsSeller {
		otherParty = p.SellerID
	}
	rootID := o.ID
	if o.ParentOfferID != nil {
		rootID = *o.ParentOfferID
	}
	var result interface{} = gin.H{"status": r.Action}
	err := h.DB.Transaction(func(tx *gorm.DB) error {
		switch r.Action {
		case "reject":
			if err := tx.Model(&o).Update("status", models.OfferRejected).Error; err != nil {
				return err
			}
			if o.ParentOfferID != nil {
				tx.Model(&models.Offer{}).Where("id = ?", rootID).Update("status", models.OfferRejected)
			}
			services.Notify(tx, otherParty, "Offer rejected", "Your offer on \""+p.Title+"\" was rejected.", "/offers")
		case "accept":
			t, err := h.reserveDeal(tx, &p, o.BuyerID, o.OfferedPricePaise, nil)
			if err != nil {
				return err
			}
			tx.Model(&o).Update("status", models.OfferAccepted)
			if o.ParentOfferID != nil {
				tx.Model(&models.Offer{}).Where("id = ?", rootID).Update("status", models.OfferAccepted)
			}
			services.Notify(tx, otherParty, "Offer accepted", "Deal agreed at ₹"+rupees(o.OfferedPricePaise)+" for \""+p.Title+"\". Arrange campus pickup.", "/transactions")
			result = gin.H{"status": "accepted", "transaction": t}
		case "counter":
			paise := int64(math.Round(r.Price * 100))
			if paise <= 0 || paise > p.PricePaise {
				return errString("counter price must be above ₹0 and not above the listed price")
			}
			if err := tx.Model(&o).Update("status", models.OfferCountered).Error; err != nil {
				return err
			}
			counter := models.Offer{ProductID: p.ID, BuyerID: o.BuyerID, ParentOfferID: &rootID, FromSeller: true,
				OfferedPricePaise: paise, Message: strings.TrimSpace(r.Message), Status: models.OfferPending}
			if err := tx.Create(&counter).Error; err != nil {
				return err
			}
			services.Notify(tx, o.BuyerID, "Counter-offer received", "The seller countered with ₹"+rupees(paise)+" on \""+p.Title+"\".", "/offers")
			result = counter
		}
		return nil
	})
	if err != nil {
		if _, isMsg := err.(errString); isMsg {
			fail(c, 409, err.Error())
		} else {
			fail(c, 500, "could not process response")
		}
		return
	}
	c.JSON(200, result)
}

func (h *Handler) WithdrawOffer(c *gin.Context) {
	id, ok := idParam(c, "id")
	if !ok {
		return
	}
	var o models.Offer
	if h.DB.First(&o, id).Error != nil || o.BuyerID != h.me(c).ID || o.ParentOfferID != nil {
		fail(c, 404, "offer not found")
		return
	}
	if o.Status != models.OfferPending && o.Status != models.OfferCountered {
		fail(c, 409, "this offer can no longer be withdrawn")
		return
	}
	h.DB.Transaction(func(tx *gorm.DB) error {
		tx.Model(&o).Update("status", models.OfferWithdrawn)
		tx.Model(&models.Offer{}).Where("parent_offer_id = ? AND status = ?", o.ID, models.OfferPending).
			Update("status", models.OfferWithdrawn)
		return nil
	})
	var p models.Product
	h.DB.First(&p, o.ProductID)
	services.Notify(h.DB, p.SellerID, "Offer withdrawn", h.me(c).Name+" withdrew their offer on \""+p.Title+"\".", "/offers")
	c.JSON(200, gin.H{"status": "withdrawn"})
}
