package handlers

import (
	"sort"
	"strings"

	"smitmarket/models"
	"smitmarket/repositories"
	"smitmarket/services"

	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// ---------- Messaging ----------

func (h *Handler) memberOf(c *gin.Context) (*models.Conversation, bool) {
	id, ok := idParam(c, "id")
	if !ok {
		return nil, false
	}
	var cv models.Conversation
	u := h.me(c)
	if h.DB.First(&cv, id).Error != nil || (cv.BuyerID != u.ID && cv.SellerID != u.ID) {
		fail(c, 404, "conversation not found")
		return nil, false
	}
	return &cv, true
}

func (h *Handler) StartConversation(c *gin.Context) {
	var r struct {
		ProductID uint   `json:"productId"`
		Message   string `json:"message"`
	}
	if c.ShouldBindJSON(&r) != nil {
		fail(c, 400, "invalid request")
		return
	}
	u := h.me(c)
	var p models.Product
	if h.DB.First(&p, r.ProductID).Error != nil || p.Status == models.ProductRemoved {
		fail(c, 404, "listing not found")
		return
	}
	if p.SellerID == u.ID {
		fail(c, 400, "you cannot message yourself about your own listing")
		return
	}
	msg := strings.TrimSpace(r.Message)
	if len(msg) > 2000 {
		fail(c, 400, "message too long")
		return
	}
	var cv models.Conversation
	err := h.DB.Where("product_id = ? AND buyer_id = ?", p.ID, u.ID).First(&cv).Error
	if err == gorm.ErrRecordNotFound {
		cv = models.Conversation{ProductID: p.ID, BuyerID: u.ID, SellerID: p.SellerID}
		if err := h.DB.Create(&cv).Error; err != nil {
			h.DB.Where("product_id = ? AND buyer_id = ?", p.ID, u.ID).First(&cv) // race: already created
		}
	}
	if msg != "" {
		h.DB.Create(&models.Message{ConversationID: cv.ID, SenderID: u.ID, Message: msg})
		services.Notify(h.DB, p.SellerID, "New message", u.Name+" messaged you about \""+p.Title+"\"", "/messages?c="+itoa(int64(cv.ID)))
	}
	c.JSON(200, cv)
}

func (h *Handler) ListConversations(c *gin.Context) {
	u := h.me(c)
	q := h.DB.Preload("Product.Images").Preload("Buyer").Preload("Seller")
	switch c.Query("role") {
	case "buyer":
		q = q.Where("buyer_id = ?", u.ID)
	case "seller":
		q = q.Where("seller_id = ?", u.ID)
	default:
		q = q.Where("buyer_id = ? OR seller_id = ?", u.ID, u.ID)
	}
	var cvs []models.Conversation
	q.Find(&cvs)
	out := make([]convRow, 0, len(cvs))
	var totalUnread int64
	for _, cv := range cvs {
		r := convRow{Conversation: cv, Role: "buyer"}
		if cv.SellerID == u.ID {
			r.Role = "seller"
		}
		var m models.Message
		if h.DB.Where("conversation_id = ?", cv.ID).Order("created_at DESC, id DESC").First(&m).Error == nil {
			r.Last = &m
		}
		h.DB.Model(&models.Message{}).Where("conversation_id = ? AND sender_id <> ? AND is_read = ?", cv.ID, u.ID, false).Count(&r.Unread)
		totalUnread += r.Unread
		out = append(out, r)
	}
	// newest activity first
	sort.Slice(out, func(i, j int) bool { return out[i].lastTime() > out[j].lastTime() })
	c.JSON(200, gin.H{"items": out, "totalUnread": totalUnread})
}

type convRow struct {
	models.Conversation
	Last   *models.Message `json:"last"`
	Unread int64           `json:"unread"`
	Role   string          `json:"role"`
}

func (r convRow) lastTime() int64 {
	if r.Last != nil {
		return r.Last.CreatedAt.UnixNano()
	}
	return r.CreatedAt.UnixNano()
}

func (h *Handler) GetMessages(c *gin.Context) {
	cv, ok := h.memberOf(c)
	if !ok {
		return
	}
	u := h.me(c)
	h.DB.Model(&models.Message{}).Where("conversation_id = ? AND sender_id <> ? AND is_read = ?", cv.ID, u.ID, false).
		Update("is_read", true)
	var msgs []models.Message
	h.DB.Where("conversation_id = ?", cv.ID).Order("created_at, id").Find(&msgs)
	h.DB.Preload("Product.Images").Preload("Buyer").Preload("Seller").First(cv, cv.ID)
	c.JSON(200, gin.H{"conversation": cv, "messages": msgs})
}

func (h *Handler) SendMessage(c *gin.Context) {
	cv, ok := h.memberOf(c)
	if !ok {
		return
	}
	var r struct {
		Message string `json:"message"`
	}
	if c.ShouldBindJSON(&r) != nil {
		fail(c, 400, "invalid request")
		return
	}
	text := strings.TrimSpace(r.Message)
	if text == "" || len(text) > 2000 {
		fail(c, 400, "message must be 1-2000 characters")
		return
	}
	u := h.me(c)
	m := models.Message{ConversationID: cv.ID, SenderID: u.ID, Message: text}
	if err := h.DB.Create(&m).Error; err != nil {
		fail(c, 500, "could not send message")
		return
	}
	to := cv.BuyerID
	if u.ID == cv.BuyerID {
		to = cv.SellerID
	}
	var p models.Product
	h.DB.First(&p, cv.ProductID)
	// avoid notification spam: only notify if there is no unread notification for this chat already
	link := "/messages?c=" + itoa(int64(cv.ID))
	var n int64
	h.DB.Model(&models.Notification{}).Where("user_id = ? AND link = ? AND is_read = ?", to, link, false).Count(&n)
	if n == 0 {
		services.Notify(h.DB, to, "New message", u.Name+" sent you a message about \""+p.Title+"\"", link)
	}
	c.JSON(201, m)
}

// ---------- Notifications ----------

func (h *Handler) ListNotifications(c *gin.Context) {
	var items []models.Notification
	h.DB.Where("user_id = ?", h.me(c).ID).Order("created_at DESC, id DESC").Limit(100).Find(&items)
	var unread int64
	h.DB.Model(&models.Notification{}).Where("user_id = ? AND is_read = ?", h.me(c).ID, false).Count(&unread)
	var unreadMsgs int64
	h.DB.Model(&models.Message{}).Where("is_read = ? AND sender_id <> ? AND conversation_id IN (?)", false, h.me(c).ID,
		h.DB.Model(&models.Conversation{}).Select("id").Where("buyer_id = ? OR seller_id = ?", h.me(c).ID, h.me(c).ID)).
		Count(&unreadMsgs)
	c.JSON(200, gin.H{"items": items, "unread": unread, "unreadMessages": unreadMsgs})
}

func (h *Handler) MarkNotificationRead(c *gin.Context) {
	id, ok := idParam(c, "id")
	if !ok {
		return
	}
	res := h.DB.Model(&models.Notification{}).Where("id = ? AND user_id = ?", id, h.me(c).ID).Update("is_read", true)
	if res.RowsAffected == 0 {
		fail(c, 404, "notification not found")
		return
	}
	c.JSON(200, gin.H{"message": "ok"})
}

func (h *Handler) MarkAllRead(c *gin.Context) {
	h.DB.Model(&models.Notification{}).Where("user_id = ? AND is_read = ?", h.me(c).ID, false).Update("is_read", true)
	c.JSON(200, gin.H{"message": "ok"})
}

// ---------- Reviews & profiles ----------

func (h *Handler) CreateReview(c *gin.Context) {
	var r struct {
		TransactionID uint   `json:"transactionId"`
		Rating        int    `json:"rating"`
		Comment       string `json:"comment"`
	}
	if c.ShouldBindJSON(&r) != nil || r.Rating < 1 || r.Rating > 5 {
		fail(c, 400, "rating must be between 1 and 5")
		return
	}
	if len(r.Comment) > 500 {
		fail(c, 400, "review too long (500 characters max)")
		return
	}
	u := h.me(c)
	var t models.Transaction
	if h.DB.First(&t, r.TransactionID).Error != nil || (t.BuyerID != u.ID && t.SellerID != u.ID) {
		fail(c, 404, "transaction not found")
		return
	}
	if t.Status != models.TxCompleted {
		fail(c, 409, "you can only review completed exchanges")
		return
	}
	reviewee := t.SellerID
	if u.ID == t.SellerID {
		reviewee = t.BuyerID
	}
	rv := models.Review{TransactionID: t.ID, ReviewerID: u.ID, RevieweeID: reviewee, Rating: r.Rating, Comment: strings.TrimSpace(r.Comment)}
	if err := h.DB.Create(&rv).Error; err != nil {
		fail(c, 409, "you have already reviewed this exchange")
		return
	}
	services.Notify(h.DB, reviewee, "New review", u.Name+" rated you "+itoa(int64(r.Rating))+"/5", "/profile/"+itoa(int64(reviewee)))
	c.JSON(201, rv)
}

func (h *Handler) UserReviews(c *gin.Context) {
	id, ok := idParam(c, "id")
	if !ok {
		return
	}
	var u models.User
	if h.DB.First(&u, id).Error != nil {
		fail(c, 404, "user not found")
		return
	}
	var rs []models.Review
	h.DB.Preload("Reviewer").Where("reviewee_id = ?", id).Order("created_at DESC").Find(&rs)
	var sold int64
	h.DB.Model(&models.Transaction{}).Where("seller_id = ? AND status = ?", id, models.TxCompleted).Count(&sold)
	avg, n := repositories.AvgRating(h.DB, id)
	var listings []models.Product
	h.DB.Preload("Images").Where("seller_id = ? AND status = ?", id, models.ProductActive).Order("created_at DESC").Limit(8).Find(&listings)
	// public view: strip private fields
	pub := gin.H{"id": u.ID, "name": u.Name, "college": u.College, "department": u.Department, "year": u.Year,
		"profileImage": u.ProfileImage, "verified": u.VerificationStatus, "createdAt": u.CreatedAt}
	c.JSON(200, gin.H{"user": pub, "avgRating": avg, "reviewCount": n, "completedSales": sold, "reviews": rs, "listings": listings})
}

// ---------- Reports (by students) ----------

func (h *Handler) CreateReport(c *gin.Context) {
	var r struct {
		ProductID   uint   `json:"productId"`
		Reason      string `json:"reason"`
		Description string `json:"description"`
	}
	if c.ShouldBindJSON(&r) != nil || strings.TrimSpace(r.Reason) == "" || len(r.Description) > 1000 {
		fail(c, 400, "a reason is required")
		return
	}
	var p models.Product
	if h.DB.First(&p, r.ProductID).Error != nil {
		fail(c, 404, "listing not found")
		return
	}
	if p.SellerID == h.me(c).ID {
		fail(c, 400, "you cannot report your own listing")
		return
	}
	var dup int64
	h.DB.Model(&models.Report{}).Where("reporter_id = ? AND product_id = ? AND status = ?", h.me(c).ID, p.ID, "pending").Count(&dup)
	if dup > 0 {
		fail(c, 409, "you have already reported this listing")
		return
	}
	rep := models.Report{ReporterID: h.me(c).ID, ProductID: p.ID, Reason: strings.TrimSpace(r.Reason),
		Description: strings.TrimSpace(r.Description), Status: "pending"}
	h.DB.Create(&rep)
	c.JSON(201, gin.H{"message": "report submitted; our admins will review it"})
}
