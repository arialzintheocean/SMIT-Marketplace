package handlers

import (
	"strings"

	"smitmarket/models"
	"smitmarket/services"

	"github.com/gin-gonic/gin"
)

// ---------- Student dashboard ----------

func (h *Handler) Dashboard(c *gin.Context) {
	u := h.me(c)
	count := func(m interface{}, where string, args ...interface{}) int64 {
		var n int64
		h.DB.Model(m).Where(where, args...).Count(&n)
		return n
	}
	var sum struct{ Total *int64 }
	h.DB.Model(&models.Transaction{}).Select("SUM(final_price_paise) as total").
		Where("seller_id = ? AND status = ?", u.ID, models.TxCompleted).Scan(&sum)
	earned := int64(0)
	if sum.Total != nil {
		earned = *sum.Total
	}
	var mine []models.Product
	h.DB.Preload("Images").Where("seller_id = ? AND status IN ?", u.ID,
		[]string{models.ProductActive, models.ProductReserved, models.ProductSold}).Order("views DESC").Find(&mine)
	type perf struct {
		ID         uint   `json:"id"`
		Title      string `json:"title"`
		Status     string `json:"status"`
		Views      int    `json:"views"`
		Interested int64  `json:"interested"`
		Image      string `json:"image"`
	}
	perfs := []perf{}
	var totalViews int
	for _, p := range mine {
		pf := perf{ID: p.ID, Title: p.Title, Status: p.Status, Views: p.Views}
		if len(p.Images) > 0 {
			pf.Image = p.Images[0].ImagePath
		}
		pf.Interested = count(&models.Wishlist{}, "product_id = ?", p.ID) +
			count(&models.Conversation{}, "product_id = ?", p.ID)
		totalViews += p.Views
		perfs = append(perfs, pf)
	}
	var mostViewed *perf
	for i := range perfs {
		if mostViewed == nil || perfs[i].Views > mostViewed.Views {
			mostViewed = &perfs[i]
		}
	}
	var recent []models.Notification
	h.DB.Where("user_id = ?", u.ID).Order("created_at DESC, id DESC").Limit(8).Find(&recent)
	var unreadMsgs int64
	h.DB.Model(&models.Message{}).Where("is_read = ? AND sender_id <> ? AND conversation_id IN (?)", false, u.ID,
		h.DB.Model(&models.Conversation{}).Select("id").Where("buyer_id = ? OR seller_id = ?", u.ID, u.ID)).Count(&unreadMsgs)

	c.JSON(200, gin.H{
		"activeListings":   count(&models.Product{}, "seller_id = ? AND status IN ?", u.ID, []string{models.ProductActive, models.ProductReserved}),
		"soldProducts":     count(&models.Product{}, "seller_id = ? AND status = ?", u.ID, models.ProductSold),
		"pendingOffers":    count(&models.Offer{}, "from_seller = ? AND status = ? AND product_id IN (?)", false, models.OfferPending, h.DB.Model(&models.Product{}).Select("id").Where("seller_id = ?", u.ID)),
		"myPendingOffers":  count(&models.Offer{}, "buyer_id = ? AND status IN ? AND parent_offer_id IS NULL", u.ID, []string{models.OfferPending, models.OfferCountered}),
		"receivedRequests": count(&models.Transaction{}, "seller_id = ? AND status = ?", u.ID, models.TxRequested),
		"sentRequests":     count(&models.Transaction{}, "buyer_id = ? AND status IN ?", u.ID, []string{models.TxRequested, models.TxReserved}),
		"savedProducts":    count(&models.Wishlist{}, "user_id = ?", u.ID),
		"unreadMessages":   unreadMsgs,
		"recentActivity":   recent,
		"analytics": gin.H{
			"totalViews": totalViews, "mostViewed": mostViewed, "completedSales": count(&models.Transaction{}, "seller_id = ? AND status = ?", u.ID, models.TxCompleted),
			"completedPurchases": count(&models.Transaction{}, "buyer_id = ? AND status = ?", u.ID, models.TxCompleted),
			"totalEarnedPaise":   earned, "listings": perfs,
		},
	})
}

// ---------- Admin ----------

func (h *Handler) AdminDashboard(c *gin.Context) {
	var students, active, sold, pending, completed int64
	h.DB.Model(&models.User{}).Where("role = ?", models.RoleStudent).Count(&students)
	h.DB.Model(&models.Product{}).Where("status IN ?", []string{models.ProductActive, models.ProductReserved}).Count(&active)
	h.DB.Model(&models.Product{}).Where("status = ?", models.ProductSold).Count(&sold)
	h.DB.Model(&models.Report{}).Where("status = ?", "pending").Count(&pending)
	h.DB.Model(&models.Transaction{}).Where("status = ?", models.TxCompleted).Count(&completed)
	type cat struct {
		Name  string `json:"name"`
		Count int64  `json:"count"`
	}
	var cats []cat
	h.DB.Table("products").Select("categories.name as name, COUNT(products.id) as count").
		Joins("JOIN categories ON categories.id = products.category_id").
		Where("products.status <> ?", models.ProductRemoved).Group("categories.name").Order("count DESC").Scan(&cats)
	var newUsers []models.User
	h.DB.Order("created_at DESC").Limit(5).Find(&newUsers)
	var newListings []models.Product
	h.DB.Preload("Seller").Order("created_at DESC").Limit(5).Find(&newListings)
	var recentTx []models.Transaction
	h.DB.Preload("Product").Preload("Buyer").Preload("Seller").Order("created_at DESC").Limit(5).Find(&recentTx)
	c.JSON(200, gin.H{"totalStudents": students, "activeListings": active, "soldProducts": sold,
		"pendingReports": pending, "completedExchanges": completed, "popularCategories": cats,
		"activity": gin.H{"newUsers": newUsers, "newListings": newListings, "recentTransactions": recentTx}})
}

func (h *Handler) AdminUsers(c *gin.Context) {
	q := h.DB.Model(&models.User{})
	if s := strings.TrimSpace(c.Query("q")); s != "" {
		like := "%" + strings.ToLower(s) + "%"
		q = q.Where("LOWER(name) LIKE ? OR LOWER(email) LIKE ?", like, like)
	}
	page, size := maxInt(intQuery(c, "page", 1), 1), 20
	var total int64
	q.Count(&total)
	var users []models.User
	q.Order("created_at DESC").Limit(size).Offset((page - 1) * size).Find(&users)
	c.JSON(200, gin.H{"items": users, "total": total, "page": page, "pageSize": size})
}

func (h *Handler) AdminSetUserStatus(c *gin.Context) {
	id, ok := idParam(c, "id")
	if !ok {
		return
	}
	var r struct {
		Status string `json:"status"`
	}
	if c.ShouldBindJSON(&r) != nil || !valid([]string{models.AccountActive, models.AccountSuspended}, r.Status) {
		fail(c, 400, "status must be active or suspended")
		return
	}
	var u models.User
	if h.DB.First(&u, id).Error != nil {
		fail(c, 404, "user not found")
		return
	}
	if u.Role == models.RoleAdmin {
		fail(c, 400, "administrator accounts cannot be suspended")
		return
	}
	h.DB.Model(&u).Update("account_status", r.Status)
	if r.Status == models.AccountSuspended {
		// take their open listings off the marketplace
		h.DB.Model(&models.Product{}).Where("seller_id = ? AND status IN ?", u.ID,
			[]string{models.ProductActive}).Update("status", models.ProductRemoved)
	}
	c.JSON(200, gin.H{"id": u.ID, "status": r.Status})
}

func (h *Handler) AdminListings(c *gin.Context) {
	q := h.DB.Model(&models.Product{})
	if s := strings.TrimSpace(c.Query("q")); s != "" {
		q = q.Where("LOWER(title) LIKE ?", "%"+strings.ToLower(s)+"%")
	}
	if s := c.Query("status"); s != "" {
		q = q.Where("status = ?", s)
	}
	page, size := maxInt(intQuery(c, "page", 1), 1), 20
	var total int64
	q.Count(&total)
	var items []models.Product
	q.Preload("Images").Preload("Seller").Preload("Category").Order("created_at DESC").
		Limit(size).Offset((page - 1) * size).Find(&items)
	c.JSON(200, gin.H{"items": items, "total": total, "page": page, "pageSize": size})
}

func (h *Handler) AdminSetListingStatus(c *gin.Context) {
	id, ok := idParam(c, "id")
	if !ok {
		return
	}
	var r struct {
		Status string `json:"status"`
	}
	if c.ShouldBindJSON(&r) != nil || !valid([]string{models.ProductActive, models.ProductRemoved}, r.Status) {
		fail(c, 400, "status must be active or removed")
		return
	}
	var p models.Product
	if h.DB.First(&p, id).Error != nil {
		fail(c, 404, "listing not found")
		return
	}
	if p.Status == models.ProductSold {
		fail(c, 409, "sold listings cannot be changed")
		return
	}
	h.DB.Model(&p).Update("status", r.Status)
	if r.Status == models.ProductRemoved {
		services.Notify(h.DB, p.SellerID, "Listing rejected", "Your listing \""+p.Title+"\" was removed by an administrator.", "/my-listings")
	} else {
		services.Notify(h.DB, p.SellerID, "Listing approved", "Your listing \""+p.Title+"\" is live again.", "/my-listings")
	}
	c.JSON(200, gin.H{"status": r.Status})
}

func (h *Handler) AdminReports(c *gin.Context) {
	q := h.DB.Preload("Reporter").Preload("Product.Seller").Preload("Product.Images")
	if s := c.Query("status"); s != "" {
		q = q.Where("status = ?", s)
	}
	var rs []models.Report
	q.Order("created_at DESC").Limit(200).Find(&rs)
	c.JSON(200, gin.H{"items": rs})
}

func (h *Handler) AdminResolveReport(c *gin.Context) {
	id, ok := idParam(c, "id")
	if !ok {
		return
	}
	var r struct {
		Status        string `json:"status"`
		RemoveListing bool   `json:"removeListing"`
	}
	if c.ShouldBindJSON(&r) != nil || !valid([]string{"resolved", "dismissed"}, r.Status) {
		fail(c, 400, "status must be resolved or dismissed")
		return
	}
	var rep models.Report
	if h.DB.First(&rep, id).Error != nil {
		fail(c, 404, "report not found")
		return
	}
	h.DB.Model(&rep).Update("status", r.Status)
	if r.RemoveListing {
		var p models.Product
		if h.DB.First(&p, rep.ProductID).Error == nil && p.Status != models.ProductSold {
			h.DB.Model(&p).Update("status", models.ProductRemoved)
			services.Notify(h.DB, p.SellerID, "Listing rejected", "Your listing \""+p.Title+"\" was removed after a report review.", "/my-listings")
		}
	}
	services.Notify(h.DB, rep.ReporterID, "Report reviewed", "Thanks — your report has been "+r.Status+".", "/")
	c.JSON(200, gin.H{"status": r.Status})
}
