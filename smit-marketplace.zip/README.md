# Smit MarketPlace – Smart Campus Marketplace

A full-stack campus marketplace where verified students buy, sell and exchange second-hand items: price negotiation, in-app messaging, a reservation → pickup → completion workflow, ratings, notifications and an admin moderation panel. No online payments; exchanges happen on campus.

| Layer | Stack |
|---|---|
| Backend | Go, Gin, GORM, SQLite (PostgreSQL-ready), JWT, bcrypt |
| Frontend | React 18 + Vite, Tailwind CSS, React Router, Axios, Recharts, Lucide |

## Project structure

```
backend/
  config/        env loading, DB connection, seeding (categories, admin, demo data)
  models/        GORM models + status constants
  repositories/  SQL-level search/filter/pagination, rating aggregates
  services/      notifications
  middleware/    JWT auth, role guard, verified-email guard
  handlers/      REST handlers (auth, products, market, transactions, social, dashboard/admin)
  routes/        route groups
  utils/         bcrypt, JWT, OTP, SMTP
  uploads/       stored images (created at runtime)
frontend/
  src/{components,pages,layouts,services,hooks,context,utils}
```

## Setup

**Prerequisites:** Go 1.21+, Node 18+.

### Backend
```bash
cd backend
cp .env.example .env        # then edit it
go mod tidy                 # downloads dependencies and writes go.sum
go run .                    # http://localhost:8080
```
Set at least:
- `JWT_SECRET` – long random string (required in production).
- `ADMIN_EMAIL` + `ADMIN_PASSWORD` – the initial admin is created on first start only if **both** are set. There is no default admin password anywhere in the code.
- `SMTP_*` – for real OTP emails. Leave `SMTP_HOST` empty in development: the OTP is printed in the server log and returned as `dev_otp` by `/api/auth/register`, and the UI shows it in a clearly labelled "Development mode" box.
- `SEED_DEMO=true` creates two clearly labelled demo accounts (`demo.seller@demo.smit.edu`, `demo.buyer@demo.smit.edu`, password `DemoPass#2026`) with four `[DEMO]` listings. Set to `false` for real deployments.

### Frontend
```bash
cd frontend
npm install
npm run dev                 # http://localhost:5173 (proxies /api and /uploads to :8080)
```
For production, `npm run build` and serve `dist/`; set `FRONTEND_ORIGIN` on the backend for CORS.

### Moving to PostgreSQL
Models use portable GORM types and integer paise for money. Add `gorm.io/driver/postgres`, add a `postgres` case in `backend/config/database.go` (`postgres.Open(DSN)`), and set `DB_DRIVER=postgres`.

## Business rules (enforced on the backend)

- **Roles:** `student`, `admin`. Admin routes require the admin role (`/api/admin/*`). Ownership is checked for listing edit/delete/status, offer responses, transaction actions, conversations and notifications.
- **Verification:** login requires a verified email (6-digit OTP, hashed at rest, 10-minute expiry). Trading actions (create listing, offers, requests, messages, reviews, reports) require a verified account. Suspended accounts are rejected on every request.
- **Money** is stored as integer paise; the API accepts rupees in forms and converts with rounding.
- **Uploads:** JPG/PNG/WEBP/GIF only (content-sniffed, not by extension), max `MAX_UPLOAD_MB` each, max 6 per listing, random filenames.
- **Offers:** only on `active` + negotiable listings, strictly below the listed price, one open offer per buyer per listing. Seller can accept / reject / counter; buyer can accept / reject a counter or withdraw. Full history is kept (counters are child rows).
- **Reservation:** accepting an offer or a purchase request runs in a DB transaction with a conditional `UPDATE … WHERE status='active'`, so only one buyer can ever win a listing. All other open offers/requests on that listing are closed and notified.
- **Transaction flow:** `requested` → (seller accepts) → `reserved` (listing reserved) → (seller marks handed over) → `completed` (listing `sold`). Either side can cancel a reserved exchange (listing returns to `active`). Seller *accepting* a request is stored as `reserved`; the `accepted` constant is accepted as the request body value only.
- **Reviews:** only on completed transactions, by buyer or seller about the other party, 1–5 stars, one per user per transaction (unique index).
- **Sold/removed listings** reject new offers, requests and edits. Deleting is a soft-delete so history stays valid; listings with a reserved exchange or completed sale cannot be deleted.

## API reference

All endpoints are under `/api`. Authenticated routes need `Authorization: Bearer <token>`. Errors return `{ "error": "message" }`.

### Auth
| Method | Path | Notes |
|---|---|---|
| POST | `/auth/register` | multipart: `name,email,password(≥8),college,department,year(1-6),profileImage?` → `201` (+`dev_otp` in dev without SMTP) |
| POST | `/auth/verify-email` | `{email, otp}` |
| POST | `/auth/resend-otp` | `{email}` |
| POST | `/auth/login` | `{email,password}` → `{token,user}`; `403 needsVerification` if unverified |
| GET | `/auth/me` | current user + rating |
| PUT | `/auth/profile` | multipart: `name,college,department,year,profileImage` |

### Products
| Method | Path | Notes |
|---|---|---|
| GET | `/categories` | categories + condition list |
| GET | `/products` | query: `q, category, minPrice, maxPrice (₹), condition (comma list), negotiable=true, sort=newest\|price_asc\|price_desc, page, pageSize` → `{items,total,page,pageSize,totalPages}` |
| GET | `/products/batch?ids=1,2` | recently viewed |
| GET | `/products/:id` | increments views (not for the owner); includes `wishlisted`, `isOwner`, seller rating |
| POST | `/products` | multipart: `title,description,price,categoryId,condition,negotiable,pickupLocation,images[]` |
| PUT | `/products/:id` | owner only; also `removeImages=1,2` |
| DELETE | `/products/:id` | owner only |
| PATCH | `/products/:id/status` | owner: `{status: active\|reserved\|sold}` |
| GET | `/products/:id/interested` | owner: users who saved/chatted/offered |
| GET | `/my/products` | own listings with wishlist/offer/chat counts |

### Wishlist / Offers
| Method | Path | Notes |
|---|---|---|
| GET/POST/DELETE | `/wishlist`, `/wishlist/:productId` | duplicates prevented (unique index) |
| POST | `/offers` | `{productId, price, message}` |
| GET | `/offers/received`, `/offers/sent` | threads with `history` |
| PATCH | `/offers/:id/respond` | `{action: accept\|reject\|counter, price?, message?}` |
| PATCH | `/offers/:id/withdraw` | buyer only |

### Messaging
| Method | Path | Notes |
|---|---|---|
| GET | `/conversations?role=buyer\|seller` | with last message + unread counts |
| POST | `/conversations` | `{productId, message}` (get-or-create) |
| GET | `/conversations/:id/messages` | members only; marks incoming messages read |
| POST | `/conversations/:id/messages` | `{message}` |

### Transactions, reviews, notifications, reports
| Method | Path | Notes |
|---|---|---|
| POST | `/transactions` | `{productId}` purchase request |
| GET | `/transactions?role=` | both roles |
| PATCH | `/transactions/:id/status` | `{status}`: seller `accepted`/`rejected`/`completed`; buyer `cancelled`; either `cancelled` when reserved |
| POST | `/reviews` | `{transactionId, rating, comment}` |
| GET | `/users/:id/reviews` | public profile, rating, reviews, active listings |
| GET | `/notifications` | list + `unread` + `unreadMessages` |
| PATCH | `/notifications/:id/read`, `/notifications/read-all` | |
| POST | `/reports` | `{productId, reason, description}` |
| GET | `/dashboard` | student stats and seller analytics |

### Admin (admin role only)
| Method | Path | Notes |
|---|---|---|
| GET | `/admin/dashboard` | totals, popular categories, platform activity |
| GET | `/admin/users?q=&page=` | |
| PATCH | `/admin/users/:id/status` | `{status: active\|suspended}` (admins can't be suspended) |
| GET | `/admin/listings?q=&status=&page=` | |
| PATCH | `/admin/listings/:id/status` | `{status: active\|removed}` – notifies the seller (approved/rejected) |
| GET | `/admin/reports?status=` | |
| PATCH | `/admin/reports/:id` | `{status: resolved\|dismissed, removeListing}` |

## Testing with Postman
1. `POST /api/auth/register` → `POST /api/auth/verify-email` with the OTP (from log / `dev_otp`) → `POST /api/auth/login`.
2. Store `token` in a collection variable and send `Authorization: Bearer {{token}}`.
3. Typical flow: create listing (form-data, `images` file field) → as a second user make an offer → seller `respond` → transaction `completed` → both users `POST /reviews`.

## Known limitations
- Messaging and notifications use polling (5–30 s), not WebSockets.
- Listings are published immediately; moderation is report-driven plus admin removal/restoration.
- Automated tests are not included.
